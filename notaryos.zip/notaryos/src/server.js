require("dotenv").config();
const fs = require("fs");
const path = require("path");
const express = require("express");
const cors = require("cors");
const Stripe = require("stripe");
const { pool } = require("./db");
const {
  hashPassword, verifyPassword, signToken,
  createSession, revokeSession, authMiddleware,
} = require("./auth");

const site = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "site.json"), "utf8"));
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "sk_test_placeholder");

// Wraps async route handlers so a thrown/rejected error (e.g. the database
// being unreachable) turns into a clean JSON error response instead of
// crashing the whole process.
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const app = express();
app.use(cors());

/* Stripe webhook needs the raw body for signature verification, so it's
   registered before express.json() touches this route. */
app.post("/api/webhooks/stripe", express.raw({ type: "application/json" }), async (req, res) => {
  if (!process.env.STRIPE_WEBHOOK_SECRET) {
    return res.status(503).json({ error: "Webhook not configured yet" });
  }
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    const already = await pool.query("SELECT 1 FROM processed_stripe_events WHERE event_id = $1", [event.id]);
    if (already.rowCount > 0) return res.json({ received: true, duplicate: true });
    await pool.query("INSERT INTO processed_stripe_events (event_id) VALUES ($1)", [event.id]);
  } catch (err) {
    console.error("Webhook idempotency check failed:", err.message);
    return res.status(500).json({ error: "internal error handling webhook" });
  }

  try {
    if (event.type === "checkout.session.completed") {
      const session = event.data.object;
      const userId = session.client_reference_id;
      if (userId) {
        await pool.query(
          `INSERT INTO subscriptions (user_id, status, stripe_customer_id, stripe_subscription_id)
           VALUES ($1, 'active', $2, $3)
           ON CONFLICT (user_id) DO UPDATE SET status='active', stripe_customer_id=$2, stripe_subscription_id=$3, updated_at=now()`,
          [userId, session.customer, session.subscription]
        );
      }
    } else if (event.type === "customer.subscription.updated") {
      const sub = event.data.object;
      const status = ["active", "trialing"].includes(sub.status) ? "active" : "past_due";
      await pool.query(
        `UPDATE subscriptions SET status=$1, current_period_end=to_timestamp($2), updated_at=now() WHERE stripe_subscription_id=$3`,
        [status, sub.current_period_end, sub.id]
      );
    } else if (event.type === "customer.subscription.deleted") {
      const sub = event.data.object;
      await pool.query(`UPDATE subscriptions SET status='cancelled', updated_at=now() WHERE stripe_subscription_id=$1`, [sub.id]);
    }
    res.json({ received: true });
  } catch (err) {
    console.error("Webhook handler error:", err);
    res.status(500).json({ error: "internal error handling webhook" });
  }
});

app.use(express.json());

/* ---------------- health ---------------- */
app.get("/", (_req, res) => res.json({ ok: true, name: site.name, version: site.version }));
app.get("/api/health", (_req, res) => res.json({ ok: true }));

/* ---------------- auth routes ---------------- */
app.post("/api/auth/signup", asyncHandler(async (req, res) => {
  const { email, password, business } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: "Email and password are required." });

  const existing = await pool.query("SELECT id FROM users WHERE email = $1", [email.toLowerCase()]);
  if (existing.rowCount > 0) return res.status(409).json({ error: "An account with that email already exists." });

  const hash = await hashPassword(password);
  const result = await pool.query(
    `INSERT INTO users (email, password_hash, business) VALUES ($1, $2, $3) RETURNING id, email, business, created_at`,
    [email.toLowerCase(), hash, business || "My Notary Practice"]
  );
  const user = result.rows[0];
  await pool.query(`INSERT INTO subscriptions (user_id, status, plan) VALUES ($1, 'trial', $2)`, [user.id, site.plan.name]);

  const token = signToken(user.id);
  await createSession(user.id, token, req.headers["user-agent"]);
  res.json({ token, user });
}));

app.post("/api/auth/login", asyncHandler(async (req, res) => {
  const { email, password } = req.body || {};
  const result = await pool.query("SELECT * FROM users WHERE email = $1", [(email || "").toLowerCase()]);
  const row = result.rows[0];
  if (!row || !(await verifyPassword(password, row.password_hash))) {
    return res.status(401).json({ error: "Incorrect email or password." });
  }
  const token = signToken(row.id);
  await createSession(row.id, token, req.headers["user-agent"]);
  const { password_hash, ...safeUser } = row;
  res.json({ token, user: safeUser });
}));

app.post("/api/auth/logout", authMiddleware, asyncHandler(async (req, res) => {
  await revokeSession(req.token);
  res.json({ ok: true });
}));

app.get("/api/me", authMiddleware, asyncHandler(async (req, res) => {
  const u = await pool.query("SELECT id, email, business, stripe_link, paypal, venmo, domain, facebook, instagram, linkedin, created_at FROM users WHERE id = $1", [req.userId]);
  const s = await pool.query("SELECT status, plan, current_period_end FROM subscriptions WHERE user_id = $1", [req.userId]);
  if (!u.rowCount) return res.status(404).json({ error: "Not found" });
  res.json({ ...u.rows[0], subscription: s.rows[0] || { status: "trial", plan: site.plan.name } });
}));

app.put("/api/me/settings", authMiddleware, asyncHandler(async (req, res) => {
  const { business, stripeLink, paypal, venmo, domain, facebook, instagram, linkedin } = req.body || {};
  const result = await pool.query(
    `UPDATE users SET business=$1, stripe_link=$2, paypal=$3, venmo=$4, domain=$5, facebook=$6, instagram=$7, linkedin=$8
     WHERE id=$9 RETURNING id, email, business, stripe_link, paypal, venmo, domain, facebook, instagram, linkedin`,
    [business, stripeLink, paypal, venmo, domain, facebook, instagram, linkedin, req.userId]
  );
  res.json(result.rows[0]);
}));

/* ---------------- billing ---------------- */
app.post("/api/billing/create-checkout-session", authMiddleware, asyncHandler(async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      payment_method_types: ["card"],
      line_items: [{ price: process.env.STRIPE_PRICE_ID || site.plan.stripePriceId, quantity: 1 }],
      client_reference_id: String(req.userId),
      success_url: process.env.CHECKOUT_SUCCESS_URL || "http://localhost:3000/welcome",
      cancel_url: process.env.CHECKOUT_CANCEL_URL || "http://localhost:3000/pricing",
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not start checkout." });
  }
}));

/* ---------------- generic CRUD factory (scoped to req.userId) ---------------- */
function crudRoutes(table, columns) {
  const cols = columns.join(", ");
  const placeholders = columns.map((_, i) => `$${i + 2}`).join(", ");

  app.get(`/api/${table}`, authMiddleware, asyncHandler(async (req, res) => {
    const result = await pool.query(`SELECT * FROM ${table} WHERE user_id = $1 ORDER BY id ASC`, [req.userId]);
    res.json(result.rows);
  }));
  app.post(`/api/${table}`, authMiddleware, asyncHandler(async (req, res) => {
    const values = columns.map((c) => req.body[c] ?? null);
    const result = await pool.query(
      `INSERT INTO ${table} (user_id, ${cols}) VALUES ($1, ${placeholders}) RETURNING *`,
      [req.userId, ...values]
    );
    res.json(result.rows[0]);
  }));
  app.put(`/api/${table}/:id`, authMiddleware, asyncHandler(async (req, res) => {
    const setClause = columns.map((c, i) => `${c} = $${i + 3}`).join(", ");
    const values = columns.map((c) => req.body[c] ?? null);
    const result = await pool.query(
      `UPDATE ${table} SET ${setClause} WHERE id = $1 AND user_id = $2 RETURNING *`,
      [req.params.id, req.userId, ...values]
    );
    if (!result.rowCount) return res.status(404).json({ error: "Not found" });
    res.json(result.rows[0]);
  }));
  app.delete(`/api/${table}/:id`, authMiddleware, asyncHandler(async (req, res) => {
    await pool.query(`DELETE FROM ${table} WHERE id = $1 AND user_id = $2`, [req.params.id, req.userId]);
    res.json({ deleted: true });
  }));
}

crudRoutes("clients", ["name", "company", "phone", "email", "address", "type", "referral", "status"]);
crudRoutes("appointments", ["client_id", "client", "phone", "email", "notary_type", "location", "date", "time", "status", "fee", "paid"]);
crudRoutes("journal_entries", ["signer", "address", "id_type", "id_number", "doc_type", "act", "fee", "date", "remarks"]);
crudRoutes("transactions", ["type", "category", "amount", "date", "deductible", "miles", "note"]);

/* ---------------- checklist (per-item key/value) ---------------- */
app.get("/api/checklist", authMiddleware, asyncHandler(async (req, res) => {
  const result = await pool.query("SELECT item_id, checked FROM checklist_progress WHERE user_id = $1", [req.userId]);
  const map = {};
  result.rows.forEach((r) => (map[r.item_id] = r.checked));
  res.json(map);
}));
app.put("/api/checklist/:itemId", authMiddleware, asyncHandler(async (req, res) => {
  const { checked } = req.body || {};
  await pool.query(
    `INSERT INTO checklist_progress (user_id, item_id, checked, updated_at) VALUES ($1, $2, $3, now())
     ON CONFLICT (user_id, item_id) DO UPDATE SET checked = $3, updated_at = now()`,
    [req.userId, req.params.itemId, !!checked]
  );
  res.json({ ok: true });
}));

const port = site.server?.port || process.env.PORT || 3000;

// Global error handler: anything asyncHandler catches (or any sync throw)
// ends up here as a clean JSON response instead of crashing the server.
app.use((err, _req, res, _next) => {
  console.error("Request error:", err.message);
  res.status(500).json({ error: "Something went wrong. Please try again." });
});

app.listen(port, () => console.log(`${site.name} backend listening on port ${port}`));

module.exports = app;
