const { Pool } = require("pg");

// A valid-looking placeholder so the app can boot and be inspected/tested
// even before a real DATABASE_URL is supplied. Real queries will fail
// until you set your actual connection string in .env.
const connectionString = process.env.DATABASE_URL || "postgres://user:password@localhost:5432/notaryos";

const pool = new Pool({
  connectionString,
  ssl: connectionString.includes("localhost") ? false : { rejectUnauthorized: false },
});

pool.on("error", (err) => {
  console.error("Unexpected database error:", err.message);
});

module.exports = { pool };
