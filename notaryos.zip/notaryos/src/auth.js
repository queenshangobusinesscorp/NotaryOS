const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const { pool } = require("./db");

const JWT_SECRET = process.env.JWT_SECRET || "dev-only-secret-change-me";
const SESSION_DAYS = 30;

/* ---------------- passwords ---------------- */
async function hashPassword(plain) {
  return bcrypt.hash(plain, 12);
}
async function verifyPassword(plain, hash) {
  return bcrypt.compare(plain, hash);
}

/* ---------------- tokens ---------------- */
function signToken(userId) {
  return jwt.sign({ sub: userId }, JWT_SECRET, { expiresIn: `${SESSION_DAYS}d` });
}
function hashToken(token) {
  return crypto.createHash("sha256").update(token).digest("hex");
}
function decodeToken(token) {
  return jwt.verify(token, JWT_SECRET); // throws if invalid/expired
}

/* ---------------- sessions ----------------
   We store a hash of each issued JWT so a session can be looked up,
   listed, or revoked (e.g. "log out everywhere") without ever keeping
   the raw token server-side. */
async function createSession(userId, token, userAgent) {
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await pool.query(
    `INSERT INTO sessions (user_id, token_hash, user_agent, expires_at) VALUES ($1, $2, $3, $4)`,
    [userId, hashToken(token), userAgent || null, expiresAt]
  );
}
async function isSessionValid(token) {
  const result = await pool.query(
    `SELECT 1 FROM sessions WHERE token_hash = $1 AND revoked_at IS NULL AND expires_at > now()`,
    [hashToken(token)]
  );
  return result.rowCount > 0;
}
async function revokeSession(token) {
  await pool.query(`UPDATE sessions SET revoked_at = now() WHERE token_hash = $1`, [hashToken(token)]);
}
async function revokeAllSessions(userId) {
  await pool.query(`UPDATE sessions SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL`, [userId]);
}

/* ---------------- express middleware ---------------- */
async function authMiddleware(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Missing auth token" });

  try {
    const payload = decodeToken(token);
    const valid = await isSessionValid(token);
    if (!valid) return res.status(401).json({ error: "Session expired or revoked" });
    req.userId = payload.sub;
    req.token = token;
    next();
  } catch (e) {
    res.status(401).json({ error: "Invalid or expired token" });
  }
}

module.exports = {
  hashPassword, verifyPassword,
  signToken, hashToken, decodeToken,
  createSession, isSessionValid, revokeSession, revokeAllSessions,
  authMiddleware,
};
