/**
 * Notary Pro Suite -- backend server
 * ------------------------------------------------------------
 * What this does:
 *   - Real signup/login with hashed passwords + JWT sessions
 *   - CRUD storage for appointments, clients, journal, finance, checklist
 *   - Stripe subscription billing for the PLATFORM (you, the owner):
 *       /api/billing/create-checkout-session  -> sends a notary to Stripe Checkout
 *       /api/webhooks/stripe                  -> Stripe tells us when they paid,
 *                                                and we flip plan = 'active' automatically
 *
 * What you still have to do yourself (see README.md):
 *   1. Create your own Stripe account + a $19/mo recurring Price.
 *   2. Fill in .env with your real DATABASE_URL, JWT_SECRET, and Stripe keys.
 *   3. Run schema.sql against your database once.
 *   4. Deploy this folder (Render / Railway / Fly.io / a VPS).
 *   5. In Stripe Dashboard -> Webhooks, point an endpoint at
 *      https://your-deployed-url.com/api/webhooks/stripe
 *      and select: checkout.session.completed, customer.subscription.updated,
 *      customer.subscription.deleted
 */

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Stripe = require("stripe");

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });

const app = express();
app.use(cors());

/* ----------------------------------------------------------------
   Stripe webhook needs the RAW body to verify the signature, so it
   must be registered BEFORE express.json() runs on this route.
---------------------------------------------------------------- */
app.post("/api/webhooks/stripe", express.raw({ type: "application/json" }), async (req, res) => {
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error("Webhook signature verification failed:", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Idempotency: Stripe may send the same event more than once.
  const already = await pool.query("SELECT 1 FROM processed_stripe_events WHERE event_id = $1", [event.id]);
  if (already.rowCount > 0) return res.json({ received: true, duplicate: true });
  await pool.query("INSERT INTO processed_stripe_events (event_id) VALUES ($1)", [event.id]);

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object;
        const userId = session.client_reference_id; // we set this when creating the session
        if (userId) {
          await pool.query(
            `UPDATE users SET plan = 'active', stripe_customer_id = $1, stripe_subscription_id = $2 WHERE id = $3`,
            [session.customer, session.subscription, userId]
          );
          console.log(`User ${userId} subscription activated.`);
        }
        break;
      }
      case "customer.subscription.updated": {
        const sub = event.data.object;
        const status = sub.status; // active, past_due, canceled, unpaid, etc.
        const plan = status === "active" || status === "trialing" ? "active" : "past_due";
        await pool.query(`UPDATE users SET plan = $1 WHERE stripe_subscription_id = $2`, [plan, sub.id]);
        break;
      }
      case "customer.subscription.deleted": {
        const sub = event.data.object;
        await pool.query(`UPDATE users SET plan = 'cancelled' WHERE stripe_subscription_id = $1`, [sub.id]);
        break;
      }
      default:
        break; // ignore other events
    }
    res.json({ received: true });
  } catch (err) {
    console.error("Webhook handler error:", err);
    res.status(500).json({ error: "internal error handling webhook" });
  }
});

app.use(express.json());

/* ---------------- auth helpers ---------------- */
function signToken(user) {
  return jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: "30d" });
}
function authMiddleware(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Missing auth token" });
  try {
    req.userId = jwt.verify(token, process.env.JWT_SECRET).id;
    next();
  } catch (e) {
    res.status(401).json({ error: "Invalid or expired token" });
  }
}
function publicUser(row) {
  const { password_hash, ...safe } = row;
  return safe;
}

/* ---------------- auth routes ---------------- */
app.post("/api/auth/signup", async (req, res) => {
  const { email, password, business } = req.body;
  if (!email || !password) return res.status(400).json({ error: "Email and password are required." });
  const existing = await pool.query("SELECT id FROM users WHERE email = $1", [email.toLowerCase()]);
  if (existing.rowCount > 0) return res.status(409).json({ error: "An account with that email already exists." });

  const hash = await bcrypt.hash(password, 12);
  const result = await pool.query(
    `INSERT INTO users (email, password_hash, business) VALUES ($1, $2, $3) RETURNING *`,
    [email.toLowerCase(), hash, business || "My Notary Practice"]
  );
  const user = result.rows[0];
  res.json({ token: signToken(user), user: publicUser(user) });
});

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  const result = await pool.query("SELECT * FROM users WHERE email = $1", [(email || "").toLowerCase()]);
  const user = result.rows[0];
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: "Incorrect email or password." });
  }
  res.json({ token: signToken(user), user: publicUser(user) });
});

app.get("/api/me", authMiddleware, async (req, res) => {
  const result = await pool.query("SELECT * FROM users WHERE id = $1", [req.userId]);
  if (!result.rowCount) return res.status(404).json({ error: "Not found" });
  res.json(publicUser(result.rows[0]));
});

app.put("/api/me/settings", authMiddleware, async (req, res) => {
  const { business, stripeLink, paypal, venmo, domain, facebook, instagram, linkedin } = req.body;
  const result = await pool.query(
    `UPDATE users SET business=$1, stripe_link=$2, paypal=$3, venmo=$4, domain=$5, facebook=$6, instagram=$7, linkedin=$8
     WHERE id=$9 RETURNING *`,
    [business, stripeLink, paypal, venmo, domain, facebook, instagram, linkedin, req.userId]
  );
  res.json(publicUser(result.rows[0]));
});

/* ---------------- billing routes (the platform's own revenue) ---------------- */
app.post("/api/billing/create-checkout-session", authMiddleware, async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      payment_method_types: ["card"],
      line_items: [{ price: process.env.STRIPE_PRICE_ID, quantity: 1 }],
      client_reference_id: String(req.userId), // <- this is how the webhook knows which user paid
      success_url: process.env.CHECKOUT_SUCCESS_URL,
      cancel_url: process.env.CHECKOUT_CANCEL_URL,
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not start checkout." });
  }
});

/* ---------------- generic CRUD factory ---------------- */
function crudRoutes(table, columns) {
  const cols = columns.join(", ");
  const placeholders = columns.map((_, i) => `$${i + 2}`).join(", ");

  app.get(`/api/${table}`, authMiddleware, async (req, res) => {
    const result = await pool.query(`SELECT * FROM ${table} WHERE user_id = $1 ORDER BY id ASC`, [req.userId]);
    res.json(result.rows);
  });

  app.post(`/api/${table}`, authMiddleware, async (req, res) => {
    const values = columns.map((c) => req.body[c] ?? null);
    const result = await pool.query(
      `INSERT INTO ${table} (user_id, ${cols}) VALUES ($1, ${placeholders}) RETURNING *`,
      [req.userId, ...values]
    );
    res.json(result.rows[0]);
  });

  app.put(`/api/${table}/:id`, authMiddleware, async (req, res) => {
    const setClause = columns.map((c, i) => `${c} = $${i + 3}`).join(", ");
    const values = columns.map((c) => req.body[c] ?? null);
    const result = await pool.query(
      `UPDATE ${table} SET ${setClause} WHERE id = $1 AND user_id = $2 RETURNING *`,
      [req.params.id, req.userId, ...values]
    );
    if (!result.rowCount) return res.status(404).json({ error: "Not found" });
    res.json(result.rows[0]);
  });

  app.delete(`/api/${table}/:id`, authMiddleware, async (req, res) => {
    await pool.query(`DELETE FROM ${table} WHERE id = $1 AND user_id = $2`, [req.params.id, req.userId]);
    res.json({ deleted: true });
  });
}

crudRoutes("appointments", ["client", "phone", "email", "notary_type", "location", "date", "time", "status", "fee", "paid"]);
crudRoutes("clients", ["name", "company", "phone", "email", "address", "type", "referral", "status"]);
crudRoutes("journal_entries", ["signer", "address", "id_type", "id_number", "doc_type", "act", "fee", "date", "remarks"]);
crudRoutes("finance_entries", ["type", "category", "amount", "date", "deductible", "miles", "note"]);

/* ---------------- checklist (simple key/value per user) ---------------- */
app.get("/api/checklist", authMiddleware, async (req, res) => {
  const result = await pool.query("SELECT item_id, checked FROM checklist_state WHERE user_id = $1", [req.userId]);
  const map = {};
  result.rows.forEach((r) => (map[r.item_id] = r.checked));
  res.json(map);
});
app.put("/api/checklist/:itemId", authMiddleware, async (req, res) => {
  const { checked } = req.body;
  await pool.query(
    `INSERT INTO checklist_state (user_id, item_id, checked) VALUES ($1, $2, $3)
     ON CONFLICT (user_id, item_id) DO UPDATE SET checked = $3`,
    [req.userId, req.params.itemId, !!checked]
  );
  res.json({ ok: true });
});

app.get("/", (_req, res) => res.send("Notary Pro Suite API is running."));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Notary Pro Suite backend listening on port ${port}`));
