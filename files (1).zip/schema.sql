-- Notary Pro Suite -- production schema
-- Run this once against your Postgres database (Supabase, Render, Railway, etc.)

CREATE TABLE IF NOT EXISTS users (
  id                      SERIAL PRIMARY KEY,
  email                   TEXT UNIQUE NOT NULL,
  password_hash           TEXT NOT NULL,
  business                TEXT NOT NULL DEFAULT 'My Notary Practice',
  plan                    TEXT NOT NULL DEFAULT 'trial',        -- trial | active | cancelled
  stripe_customer_id      TEXT,
  stripe_subscription_id  TEXT,
  stripe_link             TEXT DEFAULT '',                       -- notary's OWN payment link for their clients
  paypal                  TEXT DEFAULT '',
  venmo                   TEXT DEFAULT '',
  domain                  TEXT DEFAULT '',
  facebook                TEXT DEFAULT '',
  instagram               TEXT DEFAULT '',
  linkedin                TEXT DEFAULT '',
  created_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS appointments (
  id           SERIAL PRIMARY KEY,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  client       TEXT, phone TEXT, email TEXT,
  notary_type  TEXT, location TEXT,
  date         DATE, time TEXT,
  status       TEXT DEFAULT 'Scheduled',
  fee          NUMERIC DEFAULT 0,
  paid         TEXT DEFAULT 'Unpaid',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS clients (
  id           SERIAL PRIMARY KEY,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name         TEXT, company TEXT, phone TEXT, email TEXT, address TEXT,
  type         TEXT, referral TEXT, status TEXT DEFAULT 'Active',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS journal_entries (
  id           SERIAL PRIMARY KEY,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  signer       TEXT, address TEXT, id_type TEXT, id_number TEXT,
  doc_type     TEXT, act TEXT, fee NUMERIC DEFAULT 0, date DATE, remarks TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS finance_entries (
  id           SERIAL PRIMARY KEY,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type         TEXT, category TEXT, amount NUMERIC DEFAULT 0, date DATE,
  deductible   TEXT DEFAULT 'No', miles NUMERIC, note TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS checklist_state (
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  item_id      TEXT NOT NULL,
  checked      BOOLEAN DEFAULT false,
  PRIMARY KEY (user_id, item_id)
);

-- Idempotency guard so a webhook retried by Stripe never double-processes
CREATE TABLE IF NOT EXISTS processed_stripe_events (
  event_id     TEXT PRIMARY KEY,
  processed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
