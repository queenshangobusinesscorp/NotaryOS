import React, { useState, useEffect, useCallback, useMemo } from "react";
import {
  Calendar, Users, DollarSign, BookOpen, CheckSquare, Settings, LogOut,
  Plus, X, Check, CreditCard, Mail, Lock, Building2, Star, ArrowRight,
  Download, ExternalLink, TrendingUp, Clock, Phone, MapPin, Award,
  Trash2, Pencil, ChevronRight, AlertCircle, Facebook, Instagram,
  Linkedin, Twitter, Send, Share2, User, Sparkles
} from "lucide-react";

/* ============================================================
   NOTARY PRO SUITE
   A self-contained demo app: sign up, subscribe, and run a
   notary business — appointments, CRM, journal, bookkeeping,
   calendar export, email, and social sharing.

   IMPORTANT (read this before wiring up real money/data):
   - Auth here is a lightweight demo (stored in artifact storage,
     not encrypted). Fine for trying the product, not for real
     client PII or passwords.
   - "Subscribe" runs in demo mode by default. Paste a real Stripe
     Payment Link (from your Stripe dashboard) into Settings and
     the button will send real clients to a real, working Stripe
     checkout — no backend required for that part.
   - "Add to calendar" produces a real .ics file and a real Google
     Calendar link — both work with no account connection needed.
   - Email uses mailto: links, which open the notary's own mail
     app with the message pre-filled — real send, no backend.
   - Social buttons open real share dialogs for the notary's
     booking page. "Sign in with Google/Facebook" is shown as a
     preview of what a production build would offer once wired to
     a real OAuth backend.
   ============================================================ */

/* ============================================================
   PLATFORM OWNER CONFIG
   ------------------------------------------------------------
   Fill these in with YOUR OWN payment links/accounts. This is
   how YOU (the platform owner) collect the $19/mo subscription
   from every notary who signs up. This is completely separate
   from the PayPal/Venmo/Stripe fields inside each notary's own
   Settings tab — those belong to the notary, and are for THEIR
   clients to pay THEM for notary services. Money from those
   never touches your account.

   To go live for real:
   1. Create your own Stripe account -> Product -> recurring
      price ($19/mo) -> Payment Link. Paste it below.
   2. (Optional) Also set up PayPal Subscriptions if you want a
      PayPal option for your own subscribers.
   3. IMPORTANT: a Payment Link alone can tell a customer "pay
      here" but it can't tell this app "they paid, unlock
      access" — that confirmation requires a real backend
      listening for Stripe/PayPal webhooks. Until that backend
      exists, activation after a real payment is manual (or you
      keep "demo mode" for testing). This is the #1 thing to
      build next if you want subscriptions to unlock automatically.
   ============================================================ */
const PLATFORM = {
  stripeSubscriptionLink: "", // e.g. "https://buy.stripe.com/xxxxx" — YOUR Payment Link for the $19/mo plan
  paypalSubscriptionLink: "", // e.g. a PayPal Subscriptions button/link, if you set one up
  supportEmail: "charlesleehuggins@gmail.com",
};

/* ============================================================
   BACKEND CONNECTION
   ------------------------------------------------------------
   Leave API_BASE empty and this app runs exactly like before —
   a self-contained demo using Claude's artifact storage. Once
   you deploy the notary-backend server (see its README.md),
   paste its URL here and the app switches to talking to your
   real database and real Stripe billing automatically.
   ============================================================ */
const CONFIG = {
  API_BASE: "", // e.g. "https://notary-api.onrender.com" — no trailing slash
};
const USE_API = !!CONFIG.API_BASE;

async function apiFetch(path, { method = "GET", token, body } = {}) {
  const res = await fetch(`${CONFIG.API_BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch (e) { /* no body */ }
  if (!res.ok) throw new Error((data && data.error) || `Request failed (${res.status})`);
  return data;
}

/* Session persistence only matters once this is a real deployed website
   (USE_API true) — inside Claude's artifact preview, browser storage
   isn't available/reliable, so we skip it there and just keep the demo
   session in memory for that mode. */
function saveSession(token, user) {
  if (!USE_API) return;
  try { localStorage.setItem("nps_session", JSON.stringify({ token, user })); } catch (e) {}
}
function loadSession() {
  if (!USE_API) return null;
  try {
    const raw = localStorage.getItem("nps_session");
    return raw ? JSON.parse(raw) : null;
  } catch (e) { return null; }
}
function clearSession() {
  if (!USE_API) return;
  try { localStorage.removeItem("nps_session"); } catch (e) {}
}

/* Field-name translators between the frontend's camelCase and the
   backend's snake_case columns (only appointments & journal differ). */
const apptToApi = (a) => ({ client: a.client, phone: a.phone, email: a.email, notary_type: a.notaryType, location: a.location, date: a.date, time: a.time, status: a.status, fee: a.fee, paid: a.paid });
const apptFromApi = (r) => ({ id: String(r.id), client: r.client, phone: r.phone, email: r.email, notaryType: r.notary_type, location: r.location, date: r.date, time: r.time, status: r.status, fee: r.fee, paid: r.paid });
const journalToApi = (j) => ({ signer: j.signer, address: j.address, id_type: j.idType, id_number: j.idNumber, doc_type: j.docType, act: j.act, fee: j.fee, date: j.date, remarks: j.remarks });
const journalFromApi = (r) => ({ id: String(r.id), signer: r.signer, address: r.address, idType: r.id_type, idNumber: r.id_number, docType: r.doc_type, act: r.act, fee: r.fee, date: r.date, remarks: r.remarks });
const passThroughFromApi = (r) => ({ ...r, id: String(r.id) });
const passThroughToApi = (r) => { const { id, user_id, created_at, ...rest } = r; return rest; };

const SEAL_ICON = (
  <svg viewBox="0 0 100 100" width="36" height="36" aria-hidden="true">
    <circle cx="50" cy="50" r="46" fill="none" stroke="var(--seal)" strokeWidth="3" />
    <circle cx="50" cy="50" r="38" fill="none" stroke="var(--seal)" strokeWidth="1.5" strokeDasharray="2 4" />
    <text x="50" y="46" textAnchor="middle" fontSize="11" fontFamily="var(--font-display)" fill="var(--seal)" letterSpacing="1">NOTARY</text>
    <text x="50" y="62" textAnchor="middle" fontSize="9" fontFamily="var(--font-display)" fill="var(--seal)" letterSpacing="2">PUBLIC</text>
  </svg>
);

function useStamp() {
  const [stamping, setStamping] = useState(false);
  const fire = useCallback((cb) => {
    setStamping(true);
    setTimeout(() => { setStamping(false); if (cb) cb(); }, 620);
  }, []);
  return [stamping, fire];
}

function StampOverlay({ show }) {
  if (!show) return null;
  return (
    <div className="stamp-overlay">
      <div className="stamp-mark">{SEAL_ICON}</div>
    </div>
  );
}

/* ---------------- storage helpers ---------------- */
const KEY = {
  user: (email) => `users:${email.toLowerCase()}`,
  appts: (email) => `data:${email.toLowerCase()}:appointments`,
  clients: (email) => `data:${email.toLowerCase()}:clients`,
  journal: (email) => `data:${email.toLowerCase()}:journal`,
  finance: (email) => `data:${email.toLowerCase()}:finance`,
  checklist: (email) => `data:${email.toLowerCase()}:checklist`,
  settings: (email) => `data:${email.toLowerCase()}:settings`,
};

async function storeGet(key, shared = true) {
  try {
    const r = await window.storage.get(key, shared);
    return r ? JSON.parse(r.value) : null;
  } catch (e) {
    return null;
  }
}
async function storeSet(key, value, shared = true) {
  try {
    await window.storage.set(key, JSON.stringify(value), shared);
    return true;
  } catch (e) {
    return false;
  }
}

const uid = () => Math.random().toString(36).slice(2, 10);
const money = (n) => `$${(Number(n) || 0).toFixed(2)}`;
const todayISO = () => new Date().toISOString().slice(0, 10);

/* ---------------- ICS / Google Calendar ---------------- */
function toICSDate(dateStr, timeStr) {
  const d = new Date(`${dateStr}T${timeStr || "09:00"}:00`);
  return d.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
}
function downloadICS(appt) {
  const start = toICSDate(appt.date, appt.time);
  const endDate = new Date(`${appt.date}T${appt.time || "09:00"}:00`);
  endDate.setMinutes(endDate.getMinutes() + 45);
  const end = endDate.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
  const ics = [
    "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//NotaryProSuite//EN",
    "BEGIN:VEVENT",
    `UID:${appt.id}@notaryprosuite`,
    `DTSTAMP:${start}`,
    `DTSTART:${start}`,
    `DTEND:${end}`,
    `SUMMARY:Notary Appointment - ${appt.client}`,
    `DESCRIPTION:${appt.notaryType || "Notarization"} for ${appt.client}. Fee: ${money(appt.fee)}.`,
    `LOCATION:${appt.location || ""}`,
    "END:VEVENT", "END:VCALENDAR"
  ].join("\r\n");
  const blob = new Blob([ics], { type: "text/calendar" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = `appointment-${appt.client.replace(/\s+/g, "-")}.ics`;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
function paypalLink(username, amount) {
  if (!username) return "";
  const clean = username.replace(/^@/, "").replace(/^https?:\/\/(www\.)?paypal\.me\//i, "");
  const amt = amount ? `/${Number(amount).toFixed(2)}` : "";
  return `https://paypal.me/${clean}${amt}`;
}
function venmoLink(username, amount, note) {
  if (!username) return "";
  const clean = username.replace(/^@/, "");
  const params = new URLSearchParams({ txn: "pay" });
  if (amount) params.set("amount", Number(amount).toFixed(2));
  if (note) params.set("note", note);
  return `https://venmo.com/${clean}?${params.toString()}`;
}
function googleCalLink(appt) {
  const start = toICSDate(appt.date, appt.time);
  const endDate = new Date(`${appt.date}T${appt.time || "09:00"}:00`);
  endDate.setMinutes(endDate.getMinutes() + 45);
  const end = endDate.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
  const params = new URLSearchParams({
    action: "TEMPLATE",
    text: `Notary Appointment - ${appt.client}`,
    dates: `${start}/${end}`,
    details: `${appt.notaryType || "Notarization"} for ${appt.client}. Fee: ${money(appt.fee)}.`,
    location: appt.location || "",
  });
  return `https://calendar.google.com/calendar/render?${params.toString()}`;
}

/* ================= APP ROOT ================= */
export default function NotaryProSuite() {
  const [screen, setScreen] = useState("landing"); // landing | signup | login | checkout | app
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [stamping, fireStamp] = useStamp();
  const [toast, setToast] = useState(null);
  const [booting, setBooting] = useState(USE_API);

  const notify = (msg) => { setToast(msg); setTimeout(() => setToast(null), 2600); };

  // On load, if we're wired to a real backend, try to resume a session
  // (this is what makes returning from a Stripe Checkout redirect work).
  useEffect(() => {
    if (!USE_API) return;
    (async () => {
      const saved = loadSession();
      if (!saved) { setBooting(false); return; }
      try {
        const fresh = await apiFetch("/api/me", { token: saved.token });
        const mapped = userFromApi(fresh);
        setUser(mapped); setToken(saved.token);
        setScreen(mapped.plan === "active" ? "app" : "checkout");
      } catch (e) {
        clearSession();
      }
      setBooting(false);
    })();
  }, []);

  const handleAuthed = (u, t, destinationIfActive = "app") => {
    setUser(u); setToken(t); saveSession(t, u);
    setScreen(u.plan === "active" ? destinationIfActive : "checkout");
  };

  if (booting) return <div className="dash-loading">{SEAL_ICON}<span>Loading…</span></div>;

  return (
    <div className="npsuite-root">
      <Style />
      <StampOverlay show={stamping} />
      {toast && <div className="toast">{toast}</div>}
      {screen === "landing" && (
        <Landing
          onGetStarted={() => fireStamp(() => setScreen("signup"))}
          onLogin={() => setScreen("login")}
        />
      )}
      {screen === "signup" && (
        <AuthScreen
          mode="signup"
          onSwitch={() => setScreen("login")}
          onBack={() => setScreen("landing")}
          onDone={(u, t) => { handleAuthed(u, t); fireStamp(() => {}); }}
        />
      )}
      {screen === "login" && (
        <AuthScreen
          mode="login"
          onSwitch={() => setScreen("signup")}
          onBack={() => setScreen("landing")}
          onDone={(u, t) => handleAuthed(u, t)}
        />
      )}
      {screen === "checkout" && user && (
        <Checkout
          user={user}
          token={token}
          onSubscribed={(u) => { setUser(u); saveSession(token, u); fireStamp(() => setScreen("app")); notify("Subscription active. Welcome aboard."); }}
          onSkip={() => setScreen("app")}
        />
      )}
      {screen === "app" && user && (
        <Dashboard
          user={user}
          token={token}
          setUser={(u) => { setUser(u); saveSession(token, u); }}
          notify={notify}
          onLogout={() => { setUser(null); setToken(null); clearSession(); setScreen("landing"); }}
        />
      )}
    </div>
  );
}

/* ================= LANDING ================= */
function Landing({ onGetStarted, onLogin }) {
  return (
    <div className="landing">
      <header className="landing-nav">
        <div className="brand">{SEAL_ICON}<span>Notary Pro Suite</span></div>
        <div className="nav-actions">
          <button className="link-btn" onClick={onLogin}>Log in</button>
          <button className="btn btn-primary" onClick={onGetStarted}>Get started<ArrowRight size={16} /></button>
        </div>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">For mobile notaries &amp; loan signing agents</span>
          <h1>Run your notary practice like it's already a business, not a shoebox of receipts.</h1>
          <p>Book appointments, keep your official journal, track every dollar, and manage clients — in one place, stamped and ready.</p>
          <div className="hero-actions">
            <button className="btn btn-primary btn-lg" onClick={onGetStarted}>Start free trial<ArrowRight size={18} /></button>
            <button className="btn btn-ghost btn-lg" onClick={onLogin}>I already have an account</button>
          </div>
          <div className="hero-trust">
            <Star size={14} fill="var(--seal)" stroke="none" />
            <Star size={14} fill="var(--seal)" stroke="none" />
            <Star size={14} fill="var(--seal)" stroke="none" />
            <Star size={14} fill="var(--seal)" stroke="none" />
            <Star size={14} fill="var(--seal)" stroke="none" />
            <span>Built for mobile notaries, signing agents &amp; traditional notaries public</span>
          </div>
        </div>
        <div className="hero-visual" aria-hidden="true">
          <div className="ledger-card">
            <div className="ledger-row"><span>Appointments this month</span><b>24</b></div>
            <div className="ledger-row"><span>Completed</span><b className="ok">19</b></div>
            <div className="ledger-row"><span>Revenue MTD</span><b>$2,140.00</b></div>
            <div className="ledger-row"><span>Tax reserve set aside</span><b>$642.00</b></div>
            <div className="seal-corner">{SEAL_ICON}</div>
          </div>
        </div>
      </section>

      <section className="features">
        {[
          { icon: <Calendar size={20} />, title: "Appointments", body: "Log every signing with status, fee, and live add-to-calendar links." },
          { icon: <Users size={20} />, title: "Client CRM", body: "Track lifetime value, referral source, and who to follow up with." },
          { icon: <BookOpen size={20} />, title: "Official journal", body: "Signer ID, notarial act, and fee — organized for recordkeeping." },
          { icon: <DollarSign size={20} />, title: "Bookkeeping", body: "Income, expenses, mileage, and an automatic tax reserve." },
        ].map((f) => (
          <div className="feature-card" key={f.title}>
            <div className="feature-icon">{f.icon}</div>
            <h3>{f.title}</h3>
            <p>{f.body}</p>
          </div>
        ))}
      </section>

      <section className="pricing" id="pricing">
        <h2>One plan. Everything included.</h2>
        <div className="price-card">
          <div className="price-tag"><span className="strike">$47</span><span className="now">$19</span><span className="per">/month</span></div>
          <ul>
            <li><Check size={16} /> Unlimited appointments &amp; clients</li>
            <li><Check size={16} /> Official notary journal</li>
            <li><Check size={16} /> Bookkeeping with auto tax reserve</li>
            <li><Check size={16} /> Calendar &amp; email tools</li>
            <li><Check size={16} /> Social sharing for your booking page</li>
          </ul>
          <button className="btn btn-primary btn-lg full" onClick={onGetStarted}>Start free trial</button>
        </div>
      </section>

      <footer className="landing-footer">
        <span>© {new Date().getFullYear()} Notary Pro Suite</span>
        <span>Questions? Use the Contact tab once you're signed in.</span>
      </footer>
    </div>
  );
}

/* ================= AUTH ================= */
function AuthScreen({ mode, onSwitch, onBack, onDone }) {
  const [form, setForm] = useState({ business: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setErr(""); setBusy(true);
    const email = form.email.trim().toLowerCase();
    if (!email || !form.password) { setErr("Enter an email and password."); setBusy(false); return; }

    if (USE_API) {
      try {
        const data = await apiFetch(`/api/auth/${mode}`, {
          method: "POST",
          body: mode === "signup" ? { email, password: form.password, business: form.business } : { email, password: form.password },
        });
        setBusy(false);
        onDone(userFromApi(data.user), data.token);
      } catch (err) {
        setErr(err.message || "Something went wrong."); setBusy(false);
      }
      return;
    }

    // Demo mode (no backend configured): keep everything working inside the artifact preview.
    if (mode === "signup") {
      const existing = await storeGet(KEY.user(email));
      if (existing) { setErr("An account with that email already exists. Try logging in."); setBusy(false); return; }
      const newUser = {
        email, password: form.password, business: form.business || "My Notary Practice",
        plan: "trial", createdAt: todayISO(), social: {}, stripeLink: "", paypal: "", venmo: "", domain: "",
      };
      await storeSet(KEY.user(email), newUser);
      setBusy(false);
      onDone(newUser, null);
    } else {
      const existing = await storeGet(KEY.user(email));
      if (!existing || existing.password !== form.password) {
        setErr("No match found. Check your email and password, or sign up.");
        setBusy(false); return;
      }
      setBusy(false);
      onDone(existing, null);
    }
  };

  return (
    <div className="auth-screen">
      <button className="link-btn back" onClick={onBack}>← Back</button>
      <div className="auth-card">
        <div className="brand center">{SEAL_ICON}<span>Notary Pro Suite</span></div>
        <h2>{mode === "signup" ? "Create your account" : "Welcome back"}</h2>
        <p className="sub">{mode === "signup" ? "Set up your practice in under a minute." : "Log in to your dashboard."}</p>

        <form onSubmit={submit}>
          {mode === "signup" && (
            <label className="field">
              <span><Building2 size={14} /> Business name</span>
              <input value={form.business} onChange={(e) => setForm({ ...form, business: e.target.value })} placeholder="Coastal Mobile Notary" />
            </label>
          )}
          <label className="field">
            <span><Mail size={14} /> Email</span>
            <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" required />
          </label>
          <label className="field">
            <span><Lock size={14} /> Password</span>
            <input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="••••••••" required />
          </label>
          {err && <div className="form-err"><AlertCircle size={14} /> {err}</div>}
          <button className="btn btn-primary full" disabled={busy} type="submit">
            {busy ? "Please wait…" : mode === "signup" ? "Create account" : "Log in"}
          </button>
        </form>

        <div className="oauth-preview">
          <div className="divider"><span>or continue with</span></div>
          <div className="oauth-row">
            <button type="button" className="btn btn-ghost oauth" title="Preview only — connect a real OAuth backend to enable this">
              <span className="google-g">G</span> Google
            </button>
            <button type="button" className="btn btn-ghost oauth" title="Preview only — connect a real OAuth backend to enable this">
              <Facebook size={16} /> Facebook
            </button>
          </div>
          <p className="oauth-note">Preview only — social sign-in needs a connected OAuth backend in production.</p>
        </div>

        <p className="switch">
          {mode === "signup" ? "Already have an account?" : "New here?"}{" "}
          <button className="link-btn" onClick={onSwitch}>{mode === "signup" ? "Log in" : "Create one"}</button>
        </p>
      </div>
    </div>
  );
}

/* ================= CHECKOUT / SUBSCRIPTION ================= */
function Checkout({ user, token, onSubscribed, onSkip }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const goDemo = async () => {
    setBusy(true);
    const updated = { ...user, plan: "active", subscribedAt: todayISO() };
    await storeSet(KEY.user(user.email), updated);
    setTimeout(() => { setBusy(false); onSubscribed(updated); }, 700);
  };

  const goRealCheckout = async () => {
    setBusy(true); setErr("");
    try {
      const { url } = await apiFetch("/api/billing/create-checkout-session", { method: "POST", token });
      window.location.href = url; // leaves the app — Stripe handles payment, then redirects back
    } catch (e) {
      setErr(e.message || "Could not start checkout."); setBusy(false);
    }
  };

  const hasStripe = PLATFORM.stripeSubscriptionLink && PLATFORM.stripeSubscriptionLink.startsWith("http");
  const hasPaypal = PLATFORM.paypalSubscriptionLink && PLATFORM.paypalSubscriptionLink.startsWith("http");
  const hasAnyReal = hasStripe || hasPaypal;

  return (
    <div className="auth-screen">
      <div className="auth-card wide">
        <div className="brand center">{SEAL_ICON}<span>Notary Pro Suite</span></div>
        <h2>Activate your subscription</h2>
        <p className="sub">You're one step from your dashboard, {user.business}.</p>

        <div className="price-card in-checkout">
          <div className="price-tag"><span className="strike">$47</span><span className="now">$19</span><span className="per">/month</span></div>
          <ul>
            <li><Check size={16} /> Unlimited appointments, clients &amp; journal entries</li>
            <li><Check size={16} /> Bookkeeping with automatic 30% tax reserve</li>
            <li><Check size={16} /> Calendar export &amp; email tools</li>
            <li><Check size={16} /> Cancel anytime</li>
          </ul>

          <div className="pay-options">
            {USE_API ? (
              <button className="btn btn-primary btn-lg full" onClick={goRealCheckout} disabled={busy}>
                <CreditCard size={16} /> {busy ? "Redirecting…" : "Subscribe now — $19/mo"}
              </button>
            ) : hasStripe ? (
              <a className="btn btn-primary btn-lg full" href={PLATFORM.stripeSubscriptionLink} target="_blank" rel="noopener noreferrer">
                <CreditCard size={16} /> Pay with card (Stripe)<ExternalLink size={14} />
              </a>
            ) : hasPaypal ? (
              <a className="btn btn-lg full paypal-btn" href={PLATFORM.paypalSubscriptionLink} target="_blank" rel="noopener noreferrer">
                Pay with PayPal<ExternalLink size={14} />
              </a>
            ) : (
              <button className="btn btn-primary btn-lg full" onClick={goDemo} disabled={busy}>
                <CreditCard size={16} /> {busy ? "Processing…" : "Subscribe (demo mode)"}
              </button>
            )}
          </div>
          {err && <div className="form-err"><AlertCircle size={14} /> {err}</div>}
          <p className="fine-print">
            {USE_API
              ? "This sends you to a real, secure Stripe Checkout page. Your account activates automatically the moment payment succeeds."
              : hasAnyReal
              ? "This opens the real checkout for your Notary Pro Suite subscription. Note: without a connected backend/webhook, access won't auto-unlock after paying."
              : "No real money moves here yet. Connect the notary-backend server (see its README) to enable real, automatic billing."}
          </p>
        </div>

        <button className="link-btn" onClick={onSkip}>Skip for now, explore the dashboard</button>
      </div>
    </div>
  );
}

/* ================= DASHBOARD SHELL ================= */
const TABS = [
  { id: "overview", label: "Overview", icon: TrendingUp },
  { id: "appointments", label: "Appointments", icon: Calendar },
  { id: "clients", label: "Client CRM", icon: Users },
  { id: "journal", label: "Journal", icon: BookOpen },
  { id: "finance", label: "Bookkeeping", icon: DollarSign },
  { id: "checklist", label: "Checklist", icon: CheckSquare },
  { id: "share", label: "Email &amp; Social", icon: Share2 },
  { id: "settings", label: "Settings", icon: Settings },
];

function userFromApi(row) {
  return {
    id: row.id, email: row.email, business: row.business, plan: row.plan,
    stripeLink: row.stripe_link || "", paypal: row.paypal || "", venmo: row.venmo || "", domain: row.domain || "",
    social: { facebook: row.facebook || "", instagram: row.instagram || "", linkedin: row.linkedin || "" },
  };
}

function Dashboard({ user, token, setUser, notify, onLogout }) {
  const [tab, setTab] = useState("overview");
  const [appointments, setAppointments] = useState([]);
  const [clients, setClients] = useState([]);
  const [journal, setJournal] = useState([]);
  const [finance, setFinance] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      if (USE_API) {
        try {
          const [a, c, j, f] = await Promise.all([
            apiFetch("/api/appointments", { token }), apiFetch("/api/clients", { token }),
            apiFetch("/api/journal_entries", { token }), apiFetch("/api/finance_entries", { token }),
          ]);
          setAppointments(a.map(apptFromApi)); setClients(c.map(passThroughFromApi));
          setJournal(j.map(journalFromApi)); setFinance(f.map(passThroughFromApi));
        } catch (e) { notify(e.message || "Could not load your data."); }
      } else {
        const [a, c, j, f] = await Promise.all([
          storeGet(KEY.appts(user.email)), storeGet(KEY.clients(user.email)),
          storeGet(KEY.journal(user.email)), storeGet(KEY.finance(user.email)),
        ]);
        setAppointments(a || []); setClients(c || []); setJournal(j || []); setFinance(f || []);
      }
      setLoading(false);
    })();
  }, [user.email]);

  /* Generic sync: tabs keep calling setX(fullNewArray) exactly like before.
     When a real backend is connected, we diff the old vs new array here and
     turn that into the right POST/PUT/DELETE calls — no tab code changes
     needed either way. */
  function makeSync(resource, apiPath, toApi, fromApi, currentList, setList, localKey) {
    return async (newList) => {
      const oldList = currentList;
      setList(newList); // optimistic UI update
      if (!USE_API) { await storeSet(localKey(user.email), newList); return; }
      const newIds = new Set(newList.map((x) => x.id));
      for (const item of oldList) {
        if (!newIds.has(item.id)) {
          try { await apiFetch(`/api/${apiPath}/${item.id}`, { method: "DELETE", token }); }
          catch (e) { notify(e.message || "Could not delete that entry."); }
        }
      }
      for (const item of newList) {
        const before = oldList.find((o) => o.id === item.id);
        try {
          if (!before) {
            const created = await apiFetch(`/api/${apiPath}`, { method: "POST", token, body: toApi(item) });
            const mapped = fromApi(created);
            setList((cur) => cur.map((x) => (x.id === item.id ? mapped : x)));
          } else if (JSON.stringify(before) !== JSON.stringify(item)) {
            await apiFetch(`/api/${apiPath}/${item.id}`, { method: "PUT", token, body: toApi(item) });
          }
        } catch (e) {
          notify(e.message || "Could not save that entry.");
        }
      }
    };
  }

  const updAppts = makeSync("appointments", "appointments", apptToApi, apptFromApi, appointments, setAppointments, KEY.appts);
  const updClients = makeSync("clients", "clients", passThroughToApi, passThroughFromApi, clients, setClients, KEY.clients);
  const updJournal = makeSync("journal", "journal_entries", journalToApi, journalFromApi, journal, setJournal, KEY.journal);
  const updFinance = makeSync("finance", "finance_entries", passThroughToApi, passThroughFromApi, finance, setFinance, KEY.finance);

  const updUser = async (patch) => {
    if (USE_API) {
      try {
        const body = {
          business: patch.business ?? user.business,
          stripeLink: patch.stripeLink ?? user.stripeLink,
          paypal: patch.paypal ?? user.paypal,
          venmo: patch.venmo ?? user.venmo,
          domain: patch.domain ?? user.domain,
          facebook: patch.social?.facebook ?? user.social?.facebook ?? "",
          instagram: patch.social?.instagram ?? user.social?.instagram ?? "",
          linkedin: patch.social?.linkedin ?? user.social?.linkedin ?? "",
        };
        const row = await apiFetch("/api/me/settings", { method: "PUT", token, body });
        setUser(userFromApi(row));
      } catch (e) { notify(e.message || "Could not save settings."); }
    } else {
      const u = { ...user, ...patch };
      setUser(u);
      await storeSet(KEY.user(user.email), u);
    }
  };

  const stats = useMemo(() => {
    const month = todayISO().slice(0, 7);
    const monthAppts = appointments.filter((a) => (a.date || "").startsWith(month));
    const revenue = finance.filter((f) => f.type === "Income").reduce((s, f) => s + Number(f.amount || 0), 0);
    const expenses = finance.filter((f) => f.type === "Expense").reduce((s, f) => s + Number(f.amount || 0), 0);
    return {
      total: appointments.length,
      completed: appointments.filter((a) => a.status === "Completed").length,
      pending: appointments.filter((a) => a.status === "Pending" || a.status === "Scheduled").length,
      mtdRevenue: monthAppts.filter((a) => a.status === "Completed").reduce((s, a) => s + Number(a.fee || 0), 0),
      clients: clients.length,
      vip: clients.filter((c) => c.status === "VIP").length,
      revenue, expenses, net: revenue - expenses, reserve: (revenue - expenses) * 0.3,
    };
  }, [appointments, finance, clients]);

  if (loading) return <div className="dash-loading">{SEAL_ICON}<span>Opening your ledger…</span></div>;

  return (
    <div className="dashboard">
      <aside className="sidebar">
        <div className="brand small">{SEAL_ICON}<span>{user.business}</span></div>
        <nav>
          {TABS.map((t) => {
            const Icon = t.icon;
            return (
              <button key={t.id} className={"nav-tab" + (tab === t.id ? " active" : "")} onClick={() => setTab(t.id)}>
                <Icon size={16} /> <span>{t.label.replace("&amp;", "&")}</span>
              </button>
            );
          })}
        </nav>
        <div className="sidebar-footer">
          <div className={"plan-badge " + (user.plan === "active" ? "active" : "trial")}>
            {user.plan === "active" ? "Subscription active" : "Trial mode"}
          </div>
          <button className="nav-tab" onClick={onLogout}><LogOut size={16} /> <span>Log out</span></button>
        </div>
      </aside>

      <main className="main-panel">
        {tab === "overview" && <Overview stats={stats} appointments={appointments} business={user.business} />}
        {tab === "appointments" && <AppointmentsTab appointments={appointments} setAppointments={updAppts} clients={clients} notify={notify} user={user} />}
        {tab === "clients" && <ClientsTab clients={clients} setClients={updClients} appointments={appointments} notify={notify} />}
        {tab === "journal" && <JournalTab journal={journal} setJournal={updJournal} notify={notify} />}
        {tab === "finance" && <FinanceTab finance={finance} setFinance={updFinance} stats={stats} notify={notify} />}
        {tab === "checklist" && <ChecklistTab email={user.email} token={token} notify={notify} />}
        {tab === "share" && <ShareTab user={user} clients={clients} />}
        {tab === "settings" && <SettingsTab user={user} updUser={updUser} notify={notify} />}
      </main>
    </div>
  );
}

/* ================= OVERVIEW ================= */
function Overview({ stats, appointments, business }) {
  const upcoming = [...appointments]
    .filter((a) => a.status !== "Completed" && a.status !== "Cancelled")
    .sort((a, b) => (a.date || "").localeCompare(b.date || ""))
    .slice(0, 5);
  return (
    <div className="panel">
      <PanelHeader title={`Welcome back, ${business}`} subtitle="Here's where your practice stands today." />
      <div className="stat-grid">
        <StatCard label="Appointments" value={stats.total} icon={<Calendar size={18} />} />
        <StatCard label="Completed" value={stats.completed} icon={<Check size={18} />} tone="ok" />
        <StatCard label="Pending" value={stats.pending} icon={<Clock size={18} />} tone="warn" />
        <StatCard label="Revenue MTD" value={money(stats.mtdRevenue)} icon={<DollarSign size={18} />} />
        <StatCard label="Clients" value={stats.clients} icon={<Users size={18} />} />
        <StatCard label="Tax reserve" value={money(stats.reserve)} icon={<Award size={18} />} />
      </div>
      <div className="card">
        <h3>Upcoming appointments</h3>
        {upcoming.length === 0 ? (
          <EmptyState text="Nothing on the books yet. Add your first appointment to see it here." />
        ) : (
          <table className="table">
            <thead><tr><th>Client</th><th>Date</th><th>Type</th><th>Status</th></tr></thead>
            <tbody>
              {upcoming.map((a) => (
                <tr key={a.id}><td>{a.client}</td><td>{a.date}</td><td>{a.notaryType}</td><td><StatusPill status={a.status} /></td></tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
function StatCard({ label, value, icon, tone }) {
  return (
    <div className={"stat-card" + (tone ? " tone-" + tone : "")}>
      <div className="stat-icon">{icon}</div>
      <div><div className="stat-value">{value}</div><div className="stat-label">{label}</div></div>
    </div>
  );
}
function EmptyState({ text }) {
  return <div className="empty-state"><Sparkles size={18} /><p>{text}</p></div>;
}
function StatusPill({ status }) {
  const cls = { Completed: "ok", Scheduled: "info", Pending: "warn", Cancelled: "bad" }[status] || "info";
  return <span className={"pill " + cls}>{status}</span>;
}
function PanelHeader({ title, subtitle, action }) {
  return (
    <div className="panel-header">
      <div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div>
      {action}
    </div>
  );
}

/* ================= APPOINTMENTS ================= */
function AppointmentsTab({ appointments, setAppointments, clients, notify, user }) {
  const [editing, setEditing] = useState(null);
  const blank = { id: "", client: "", phone: "", email: "", notaryType: "Acknowledgment", location: "", date: todayISO(), time: "09:00", status: "Scheduled", fee: "", paid: "Unpaid" };

  const save = (rec) => {
    const exists = appointments.some((a) => a.id === rec.id);
    const list = exists ? appointments.map((a) => (a.id === rec.id ? rec : a)) : [...appointments, { ...rec, id: uid() }];
    setAppointments(list);
    setEditing(null);
    notify(exists ? "Appointment updated." : "Appointment added.");
  };
  const remove = (id) => { setAppointments(appointments.filter((a) => a.id !== id)); notify("Appointment removed."); };

  return (
    <div className="panel">
      <PanelHeader title="Appointments" subtitle="Log signings, track status, and export to your calendar."
        action={<button className="btn btn-primary" onClick={() => setEditing(blank)}><Plus size={16} /> New appointment</button>} />

      {appointments.length === 0 ? (
        <EmptyState text="No appointments yet. Add one to get started." />
      ) : (
        <div className="card table-card">
          <table className="table">
            <thead><tr><th>#</th><th>Client</th><th>Type</th><th>Date</th><th>Fee</th><th>Status</th><th>Payment</th><th>Calendar</th><th>Get paid</th><th></th></tr></thead>
            <tbody>
              {appointments.map((a, i) => (
                <tr key={a.id}>
                  <td>{i + 1}</td>
                  <td>{a.client}</td>
                  <td>{a.notaryType}</td>
                  <td>{a.date} {a.time}</td>
                  <td>{money(a.fee)}</td>
                  <td><StatusPill status={a.status} /></td>
                  <td><span className={"pill " + (a.paid === "Paid" ? "ok" : "warn")}>{a.paid}</span></td>
                  <td className="cal-cell">
                    <button className="icon-btn" title="Download .ics" onClick={() => downloadICS(a)}><Download size={14} /></button>
                    <a className="icon-btn" title="Add to Google Calendar" href={googleCalLink(a)} target="_blank" rel="noopener noreferrer"><Calendar size={14} /></a>
                  </td>
                  <td className="cal-cell">
                    {user?.paypal && a.fee ? (
                      <a className="icon-btn" title="Request via PayPal" href={paypalLink(user.paypal, a.fee)} target="_blank" rel="noopener noreferrer">PP</a>
                    ) : null}
                    {user?.venmo && a.fee ? (
                      <a className="icon-btn" title="Request via Venmo" href={venmoLink(user.venmo, a.fee, `${a.notaryType} - ${a.client}`)} target="_blank" rel="noopener noreferrer">Ve</a>
                    ) : null}
                    {!user?.paypal && !user?.venmo && <span className="muted">Add in Settings</span>}
                  </td>
                  <td className="row-actions">
                    <button className="icon-btn" onClick={() => setEditing(a)}><Pencil size={14} /></button>
                    <button className="icon-btn danger" onClick={() => remove(a.id)}><Trash2 size={14} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing && (
        <Modal onClose={() => setEditing(null)} title={editing.id ? "Edit appointment" : "New appointment"}>
          <AppointmentForm initial={editing} clients={clients} onSave={save} onCancel={() => setEditing(null)} />
        </Modal>
      )}
    </div>
  );
}
function AppointmentForm({ initial, clients, onSave, onCancel }) {
  const [f, setF] = useState(initial);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSave(f); }} className="form-grid">
      <label className="field"><span>Client name</span>
        <input list="client-names" value={f.client} onChange={set("client")} required />
        <datalist id="client-names">{clients.map((c) => <option key={c.id} value={c.name} />)}</datalist>
      </label>
      <label className="field"><span>Phone</span><input value={f.phone} onChange={set("phone")} /></label>
      <label className="field"><span>Email</span><input type="email" value={f.email} onChange={set("email")} /></label>
      <label className="field"><span>Notary type</span>
        <select value={f.notaryType} onChange={set("notaryType")}>
          {["Acknowledgment", "Jurat", "Loan Signing", "Power of Attorney", "Affidavit", "Other"].map((o) => <option key={o}>{o}</option>)}
        </select>
      </label>
      <label className="field"><span>Location</span><input value={f.location} onChange={set("location")} placeholder="Client's home, office…" /></label>
      <label className="field"><span>Date</span><input type="date" value={f.date} onChange={set("date")} required /></label>
      <label className="field"><span>Time</span><input type="time" value={f.time} onChange={set("time")} /></label>
      <label className="field"><span>Fee</span><input type="number" step="0.01" value={f.fee} onChange={set("fee")} /></label>
      <label className="field"><span>Status</span>
        <select value={f.status} onChange={set("status")}>{["Scheduled", "Pending", "Completed", "Cancelled"].map((o) => <option key={o}>{o}</option>)}</select>
      </label>
      <label className="field"><span>Payment</span>
        <select value={f.paid} onChange={set("paid")}>{["Unpaid", "Paid", "Partial"].map((o) => <option key={o}>{o}</option>)}</select>
      </label>
      <div className="form-actions">
        <button type="button" className="btn btn-ghost" onClick={onCancel}>Cancel</button>
        <button type="submit" className="btn btn-primary">Save appointment</button>
      </div>
    </form>
  );
}

/* ================= CLIENTS / CRM ================= */
function ClientsTab({ clients, setClients, appointments, notify }) {
  const [editing, setEditing] = useState(null);
  const blank = { id: "", name: "", company: "", phone: "", email: "", address: "", type: "Individual", referral: "", status: "Active" };

  const withStats = clients.map((c) => {
    const rel = appointments.filter((a) => a.client === c.name);
    const lifetimeValue = rel.filter((a) => a.status === "Completed").reduce((s, a) => s + Number(a.fee || 0), 0);
    return { ...c, apptCount: rel.length, lifetimeValue, last: rel.map((a) => a.date).sort().slice(-1)[0] || "—" };
  });

  const save = (rec) => {
    const exists = clients.some((c) => c.id === rec.id);
    const list = exists ? clients.map((c) => (c.id === rec.id ? rec : c)) : [...clients, { ...rec, id: uid() }];
    setClients(list); setEditing(null);
    notify(exists ? "Client updated." : "Client added.");
  };
  const remove = (id) => { setClients(clients.filter((c) => c.id !== id)); notify("Client removed."); };

  return (
    <div className="panel">
      <PanelHeader title="Client CRM" subtitle="Every contact, their history, and their value to your practice."
        action={<button className="btn btn-primary" onClick={() => setEditing(blank)}><Plus size={16} /> New client</button>} />

      <div className="stat-grid">
        <StatCard label="Total clients" value={clients.length} icon={<Users size={18} />} />
        <StatCard label="Active" value={clients.filter((c) => c.status === "Active").length} icon={<Check size={18} />} tone="ok" />
        <StatCard label="VIP" value={clients.filter((c) => c.status === "VIP").length} icon={<Star size={18} />} />
        <StatCard label="Avg. lifetime value" value={money(withStats.reduce((s, c) => s + c.lifetimeValue, 0) / (clients.length || 1))} icon={<DollarSign size={18} />} />
      </div>

      {clients.length === 0 ? (
        <EmptyState text="No clients yet. Add one, or they'll appear automatically as you log appointments." />
      ) : (
        <div className="card table-card">
          <table className="table">
            <thead><tr><th>Name</th><th>Contact</th><th>Type</th><th>Status</th><th>Appointments</th><th>Lifetime value</th><th>Last seen</th><th></th></tr></thead>
            <tbody>
              {withStats.map((c) => (
                <tr key={c.id}>
                  <td>{c.name}{c.company && <div className="muted">{c.company}</div>}</td>
                  <td>{c.phone}<div className="muted">{c.email}</div></td>
                  <td>{c.type}</td>
                  <td><span className={"pill " + ({ VIP: "gold", Active: "ok", Inactive: "info", "Do Not Contact": "bad" }[c.status] || "info")}>{c.status}</span></td>
                  <td>{c.apptCount}</td>
                  <td>{money(c.lifetimeValue)}</td>
                  <td>{c.last}</td>
                  <td className="row-actions">
                    <button className="icon-btn" onClick={() => setEditing(c)}><Pencil size={14} /></button>
                    <button className="icon-btn danger" onClick={() => remove(c.id)}><Trash2 size={14} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing && (
        <Modal onClose={() => setEditing(null)} title={editing.id ? "Edit client" : "New client"}>
          <ClientForm initial={editing} onSave={save} onCancel={() => setEditing(null)} />
        </Modal>
      )}
    </div>
  );
}
function ClientForm({ initial, onSave, onCancel }) {
  const [f, setF] = useState(initial);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSave(f); }} className="form-grid">
      <label className="field"><span>Name</span><input value={f.name} onChange={set("name")} required /></label>
      <label className="field"><span>Company</span><input value={f.company} onChange={set("company")} /></label>
      <label className="field"><span>Phone</span><input value={f.phone} onChange={set("phone")} /></label>
      <label className="field"><span>Email</span><input type="email" value={f.email} onChange={set("email")} /></label>
      <label className="field wide"><span>Address</span><input value={f.address} onChange={set("address")} /></label>
      <label className="field"><span>Client type</span>
        <select value={f.type} onChange={set("type")}>{["Individual", "Title Company", "Law Firm", "Real Estate Agent", "Signing Service", "Other"].map((o) => <option key={o}>{o}</option>)}</select>
      </label>
      <label className="field"><span>Referral source</span><input value={f.referral} onChange={set("referral")} /></label>
      <label className="field"><span>Status</span>
        <select value={f.status} onChange={set("status")}>{["Active", "Inactive", "VIP", "Do Not Contact"].map((o) => <option key={o}>{o}</option>)}</select>
      </label>
      <div className="form-actions">
        <button type="button" className="btn btn-ghost" onClick={onCancel}>Cancel</button>
        <button type="submit" className="btn btn-primary">Save client</button>
      </div>
    </form>
  );
}

/* ================= JOURNAL ================= */
function JournalTab({ journal, setJournal, notify }) {
  const [editing, setEditing] = useState(null);
  const blank = { id: "", signer: "", address: "", idType: "Driver's License", idNumber: "", docType: "", act: "Acknowledgment", fee: "", date: todayISO(), remarks: "" };

  const save = (rec) => {
    const exists = journal.some((j) => j.id === rec.id);
    const list = exists ? journal.map((j) => (j.id === rec.id ? rec : j)) : [...journal, { ...rec, id: uid() }];
    setJournal(list); setEditing(null);
    notify(exists ? "Journal entry updated." : "Journal entry recorded.");
  };
  const remove = (id) => { setJournal(journal.filter((j) => j.id !== id)); notify("Entry removed."); };

  return (
    <div className="panel">
      <PanelHeader title="Official journal" subtitle={`${journal.length} of 300 entries used — organized for recordkeeping requirements.`}
        action={<button className="btn btn-primary" onClick={() => setEditing(blank)}><Plus size={16} /> New entry</button>} />

      {journal.length === 0 ? (
        <EmptyState text="Your journal is empty. Record your first notarial act." />
      ) : (
        <div className="card table-card">
          <table className="table mono">
            <thead><tr><th>#</th><th>Date</th><th>Signer</th><th>ID</th><th>Document</th><th>Act</th><th>Fee</th><th></th></tr></thead>
            <tbody>
              {journal.map((j, i) => (
                <tr key={j.id}>
                  <td>{i + 1}</td><td>{j.date}</td><td>{j.signer}</td>
                  <td>{j.idType} {j.idNumber}</td><td>{j.docType}</td><td>{j.act}</td><td>{money(j.fee)}</td>
                  <td className="row-actions">
                    <button className="icon-btn" onClick={() => setEditing(j)}><Pencil size={14} /></button>
                    <button className="icon-btn danger" onClick={() => remove(j.id)}><Trash2 size={14} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing && (
        <Modal onClose={() => setEditing(null)} title="Journal entry">
          <form onSubmit={(e) => { e.preventDefault(); save(editing); }} className="form-grid">
            <label className="field"><span>Signer name</span><input value={editing.signer} onChange={(e) => setEditing({ ...editing, signer: e.target.value })} required /></label>
            <label className="field wide"><span>Address</span><input value={editing.address} onChange={(e) => setEditing({ ...editing, address: e.target.value })} /></label>
            <label className="field"><span>ID type</span>
              <select value={editing.idType} onChange={(e) => setEditing({ ...editing, idType: e.target.value })}>
                {["Driver's License", "Passport", "State ID", "Military ID", "Other"].map((o) => <option key={o}>{o}</option>)}
              </select>
            </label>
            <label className="field"><span>ID number</span><input value={editing.idNumber} onChange={(e) => setEditing({ ...editing, idNumber: e.target.value })} /></label>
            <label className="field"><span>Document type</span><input value={editing.docType} onChange={(e) => setEditing({ ...editing, docType: e.target.value })} /></label>
            <label className="field"><span>Notarial act</span>
              <select value={editing.act} onChange={(e) => setEditing({ ...editing, act: e.target.value })}>
                {["Acknowledgment", "Jurat", "Oath/Affirmation", "Copy Certification", "Other"].map((o) => <option key={o}>{o}</option>)}
              </select>
            </label>
            <label className="field"><span>Date</span><input type="date" value={editing.date} onChange={(e) => setEditing({ ...editing, date: e.target.value })} /></label>
            <label className="field"><span>Fee</span><input type="number" step="0.01" value={editing.fee} onChange={(e) => setEditing({ ...editing, fee: e.target.value })} /></label>
            <label className="field wide"><span>Remarks</span><input value={editing.remarks} onChange={(e) => setEditing({ ...editing, remarks: e.target.value })} /></label>
            <div className="form-actions">
              <button type="button" className="btn btn-ghost" onClick={() => setEditing(null)}>Cancel</button>
              <button type="submit" className="btn btn-primary">Save entry</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

/* ================= FINANCE ================= */
function FinanceTab({ finance, setFinance, stats, notify }) {
  const [editing, setEditing] = useState(null);
  const blank = { id: "", type: "Income", category: "Signing Fee", amount: "", date: todayISO(), deductible: "No", miles: "", note: "" };

  const save = (rec) => {
    const exists = finance.some((f) => f.id === rec.id);
    const list = exists ? finance.map((f) => (f.id === rec.id ? rec : f)) : [...finance, { ...rec, id: uid() }];
    setFinance(list); setEditing(null);
    notify(exists ? "Entry updated." : "Entry logged.");
  };
  const remove = (id) => { setFinance(finance.filter((f) => f.id !== id)); notify("Entry removed."); };

  return (
    <div className="panel">
      <PanelHeader title="Bookkeeping" subtitle="Income, expenses, mileage, and your tax reserve — calculated automatically."
        action={<button className="btn btn-primary" onClick={() => setEditing(blank)}><Plus size={16} /> New entry</button>} />

      <div className="stat-grid">
        <StatCard label="Total revenue" value={money(stats.revenue)} icon={<TrendingUp size={18} />} tone="ok" />
        <StatCard label="Total expenses" value={money(stats.expenses)} icon={<DollarSign size={18} />} tone="warn" />
        <StatCard label="Net profit" value={money(stats.net)} icon={<Award size={18} />} />
        <StatCard label="Tax reserve (30%)" value={money(stats.reserve)} icon={<Lock size={18} />} />
      </div>

      {finance.length === 0 ? (
        <EmptyState text="No income or expenses logged yet." />
      ) : (
        <div className="card table-card">
          <table className="table">
            <thead><tr><th>Date</th><th>Type</th><th>Category</th><th>Amount</th><th>Deductible</th><th>Miles</th><th></th></tr></thead>
            <tbody>
              {finance.map((f) => (
                <tr key={f.id}>
                  <td>{f.date}</td>
                  <td><span className={"pill " + (f.type === "Income" ? "ok" : "warn")}>{f.type}</span></td>
                  <td>{f.category}</td><td>{money(f.amount)}</td><td>{f.deductible}</td><td>{f.miles || "—"}</td>
                  <td className="row-actions">
                    <button className="icon-btn" onClick={() => setEditing(f)}><Pencil size={14} /></button>
                    <button className="icon-btn danger" onClick={() => remove(f.id)}><Trash2 size={14} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing && (
        <Modal onClose={() => setEditing(null)} title="Bookkeeping entry">
          <form onSubmit={(e) => { e.preventDefault(); save(editing); }} className="form-grid">
            <label className="field"><span>Type</span>
              <select value={editing.type} onChange={(e) => setEditing({ ...editing, type: e.target.value })}>{["Income", "Expense"].map((o) => <option key={o}>{o}</option>)}</select>
            </label>
            <label className="field"><span>Category</span><input value={editing.category} onChange={(e) => setEditing({ ...editing, category: e.target.value })} /></label>
            <label className="field"><span>Amount</span><input type="number" step="0.01" value={editing.amount} onChange={(e) => setEditing({ ...editing, amount: e.target.value })} /></label>
            <label className="field"><span>Date</span><input type="date" value={editing.date} onChange={(e) => setEditing({ ...editing, date: e.target.value })} /></label>
            <label className="field"><span>Tax deductible?</span>
              <select value={editing.deductible} onChange={(e) => setEditing({ ...editing, deductible: e.target.value })}>{["No", "Yes"].map((o) => <option key={o}>{o}</option>)}</select>
            </label>
            <label className="field"><span>Miles (optional)</span><input type="number" value={editing.miles} onChange={(e) => setEditing({ ...editing, miles: e.target.value })} /></label>
            <label className="field wide"><span>Note</span><input value={editing.note} onChange={(e) => setEditing({ ...editing, note: e.target.value })} /></label>
            <div className="form-actions">
              <button type="button" className="btn btn-ghost" onClick={() => setEditing(null)}>Cancel</button>
              <button type="submit" className="btn btn-primary">Save entry</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

/* ================= CHECKLIST ================= */
const CHECKLIST_SECTIONS = [
  { title: "Before the appointment", items: ["Confirm date, time, and location with signer", "Verify document type and number of signers", "Confirm fee and payment method", "Review documents for blank spaces", "Charge phone / pack supplies"] },
  { title: "Identity verification", items: ["Check government-issued photo ID", "Verify name matches document exactly", "Check ID expiration date", "Note ID type and number in journal"] },
  { title: "During the appointment", items: ["Confirm signer understands the document", "Confirm signer is signing willingly", "Watch signature happen in person", "Complete notarial certificate correctly"] },
  { title: "Document completion", items: ["Fill in all journal fields", "Collect thumbprint if required by state", "Affix seal and signature", "Make copies if requested"] },
  { title: "After the appointment", items: ["Collect payment", "Log appointment as completed", "Send confirmation / receipt", "File or return original documents"] },
  { title: "Supplies & equipment", items: ["Notary seal / stamp", "Journal", "Black ink pens", "Thumbprint pad", "ID scanner or copier"] },
];
function ChecklistTab({ email, token, notify }) {
  const [checked, setChecked] = useState({});
  useEffect(() => {
    (async () => {
      if (USE_API) {
        try { setChecked(await apiFetch("/api/checklist", { token })); }
        catch (e) { notify(e.message || "Could not load checklist."); }
      } else {
        setChecked((await storeGet(KEY.checklist(email))) || {});
      }
    })();
  }, [email]);
  const toggle = async (id) => {
    const next = { ...checked, [id]: !checked[id] };
    setChecked(next);
    if (USE_API) {
      try { await apiFetch(`/api/checklist/${encodeURIComponent(id)}`, { method: "PUT", token, body: { checked: next[id] } }); }
      catch (e) { notify(e.message || "Could not save that step."); }
    } else {
      storeSet(KEY.checklist(email), next);
    }
  };
  const total = CHECKLIST_SECTIONS.reduce((s, sec) => s + sec.items.length, 0);
  const done = Object.values(checked).filter(Boolean).length;
  const resetAll = async () => {
    setChecked({});
    if (USE_API) {
      try { await Promise.all(Object.keys(checked).map((id) => apiFetch(`/api/checklist/${encodeURIComponent(id)}`, { method: "PUT", token, body: { checked: false } }))); }
      catch (e) { /* best-effort */ }
    } else {
      storeSet(KEY.checklist(email), {});
    }
    notify("Checklist reset.");
  };

  return (
    <div className="panel">
      <PanelHeader title="Signing checklist" subtitle={`${done} of ${total} steps checked`}
        action={<button className="btn btn-ghost" onClick={resetAll}>Reset all</button>} />
      <div className="checklist-grid">
        {CHECKLIST_SECTIONS.map((sec) => (
          <div className="card" key={sec.title}>
            <h3>{sec.title}</h3>
            {sec.items.map((item, idx) => {
              const id = sec.title + idx;
              return (
                <label className="check-row" key={id}>
                  <input type="checkbox" checked={!!checked[id]} onChange={() => toggle(id)} />
                  <span className={checked[id] ? "done" : ""}>{item}</span>
                </label>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================= EMAIL & SOCIAL ================= */
function ShareTab({ user, clients }) {
  const bookingUrl = `https://book.notaryprosuite.app/${encodeURIComponent(user.business.replace(/\s+/g, "-").toLowerCase())}`;
  const [emailClientId, setEmailClientId] = useState(clients[0]?.id || "");
  const client = clients.find((c) => c.id === emailClientId);

  const mailtoReminder = () => {
    if (!client) return "";
    const subject = encodeURIComponent(`Reminder: your notary appointment with ${user.business}`);
    const body = encodeURIComponent(`Hi ${client.name},\n\nJust confirming your upcoming notary appointment with ${user.business}.\n\nIf anything changes, reply to this email or call us.\n\nThanks,\n${user.business}`);
    return `mailto:${client.email || ""}?subject=${subject}&body=${body}`;
  };

  const shareText = encodeURIComponent(`Book a notary appointment with ${user.business}: ${bookingUrl}`);
  const socialLinks = [
    { label: "Facebook", icon: Facebook, url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(bookingUrl)}` },
    { label: "X / Twitter", icon: Twitter, url: `https://twitter.com/intent/tweet?text=${shareText}` },
    { label: "LinkedIn", icon: Linkedin, url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(bookingUrl)}` },
    { label: "WhatsApp", icon: Send, url: `https://wa.me/?text=${shareText}` },
  ];

  return (
    <div className="panel">
      <PanelHeader title="Email &amp; social" subtitle="Reach clients directly and share your booking page." />

      <div className="card">
        <h3><Mail size={16} /> Email a client</h3>
        <p className="muted small">Opens your own email app with the message ready to send — no account connection needed.</p>
        <div className="inline-form">
          <select value={emailClientId} onChange={(e) => setEmailClientId(e.target.value)}>
            <option value="">Select a client…</option>
            {clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <a className={"btn btn-primary" + (!client ? " disabled" : "")} href={client ? mailtoReminder() : undefined} onClick={(e) => !client && e.preventDefault()}>
            <Mail size={16} /> Draft reminder email
          </a>
        </div>
      </div>

      <div className="card">
        <h3><CreditCard size={16} /> Accept payments</h3>
        <p className="muted small">Send clients a direct payment link — no invoice needed.</p>
        <div className="social-row">
          {user.stripeLink && <a className="btn btn-ghost" href={user.stripeLink} target="_blank" rel="noopener noreferrer"><CreditCard size={16} /> Stripe</a>}
          {user.paypal && <a className="btn paypal-btn" href={paypalLink(user.paypal)} target="_blank" rel="noopener noreferrer">PayPal</a>}
          {user.venmo && <a className="btn venmo-btn" href={venmoLink(user.venmo)} target="_blank" rel="noopener noreferrer">Venmo</a>}
          {!user.stripeLink && !user.paypal && !user.venmo && <span className="muted small">Add Stripe, PayPal, or Venmo in Settings to enable these.</span>}
        </div>
      </div>

      <div className="card">
        <h3><Share2 size={16} /> Your booking page</h3>
        <p className="muted small">Share this link so clients can request appointments.</p>
        <div className="inline-form">
          <input className="share-url" readOnly value={bookingUrl} onFocus={(e) => e.target.select()} />
        </div>
        <div className="social-row">
          {socialLinks.map((s) => {
            const Icon = s.icon;
            return (
              <a key={s.label} className="btn btn-ghost" href={s.url} target="_blank" rel="noopener noreferrer">
                <Icon size={16} /> Share on {s.label}
              </a>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ================= SETTINGS ================= */
function SettingsTab({ user, updUser, notify }) {
  const [form, setForm] = useState({
    business: user.business, stripeLink: user.stripeLink || "", paypal: user.paypal || "", venmo: user.venmo || "",
    domain: user.domain || "",
    facebook: user.social?.facebook || "", instagram: user.social?.instagram || "", linkedin: user.social?.linkedin || "",
  });
  const save = async (e) => {
    e.preventDefault();
    await updUser({
      business: form.business, stripeLink: form.stripeLink, paypal: form.paypal, venmo: form.venmo, domain: form.domain,
      social: { facebook: form.facebook, instagram: form.instagram, linkedin: form.linkedin },
    });
    notify("Settings saved.");
  };
  return (
    <div className="panel">
      <PanelHeader title="Settings" subtitle="Business details, payments, and connected accounts." />
      <form className="card form-grid" onSubmit={save}>
        <label className="field wide"><span><Building2 size={14} /> Business name</span>
          <input value={form.business} onChange={(e) => setForm({ ...form, business: e.target.value })} />
        </label>

        <label className="field wide"><span><CreditCard size={14} /> Your Stripe Payment Link (for your notary clients)</span>
          <input placeholder="https://buy.stripe.com/..." value={form.stripeLink} onChange={(e) => setForm({ ...form, stripeLink: e.target.value })} />
        </label>
        <label className="field"><span>PayPal.me username</span><input placeholder="yourname" value={form.paypal} onChange={(e) => setForm({ ...form, paypal: e.target.value })} /></label>
        <label className="field"><span>Venmo username</span><input placeholder="@yourname" value={form.venmo} onChange={(e) => setForm({ ...form, venmo: e.target.value })} /></label>
        <p className="muted small wide">These links are for <b>your own clients</b> to pay <b>you</b> for notary services (appointment fees) — this money goes straight to your own Stripe/PayPal/Venmo account, not to the app. Your Notary Pro Suite subscription is billed separately by the platform.</p>

        <label className="field wide"><span>Custom domain</span><input placeholder="www.yournotarybusiness.com" value={form.domain} onChange={(e) => setForm({ ...form, domain: e.target.value })} /></label>
        <p className="muted small wide">
          This app runs inside Claude right now, so a domain can't be pointed at it directly from here. To put it on your own domain as a real website: export/host this code (Anthropic's <b>Claude Code</b> or <b>Claude for Chrome</b> apps can help with that), deploy it to a host like Vercel or Netlify, then point your domain's DNS (an A or CNAME record, set at your registrar — GoDaddy, Namecheap, etc.) at that host. Once live, your booking link on the Email &amp; Social tab can be updated to your real domain.
        </p>

        <label className="field"><span><Facebook size={14} /> Facebook page</span><input value={form.facebook} onChange={(e) => setForm({ ...form, facebook: e.target.value })} placeholder="https://facebook.com/..." /></label>
        <label className="field"><span><Instagram size={14} /> Instagram</span><input value={form.instagram} onChange={(e) => setForm({ ...form, instagram: e.target.value })} placeholder="https://instagram.com/..." /></label>
        <label className="field"><span><Linkedin size={14} /> LinkedIn</span><input value={form.linkedin} onChange={(e) => setForm({ ...form, linkedin: e.target.value })} placeholder="https://linkedin.com/..." /></label>

        <div className="form-actions wide"><button className="btn btn-primary" type="submit">Save settings</button></div>
      </form>

      <div className="card">
        <h3>Plan</h3>
        <p className="muted small">Current status: <b>{user.plan === "active" ? "Subscription active" : "Trial"}</b></p>
      </div>
    </div>
  );
}

/* ================= SHARED UI ================= */
function Modal({ title, onClose, children }) {
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head"><h3>{title}</h3><button className="icon-btn" onClick={onClose}><X size={16} /></button></div>
        <div className="modal-body">{children}</div>
      </div>
    </div>
  );
}

/* ================= STYLES ================= */
function Style() {
  return (
    <style>{`
      .npsuite-root{
        --ink:#1C2B45; --ink-soft:#33405C; --seal:#B8925A; --seal-dark:#96703F;
        --parchment:#F6F1E7; --parchment-deep:#EDE4D3; --leather:#5C4632;
        --ok:#4E7A5B; --warn:#B8863A; --bad:#A24B3E; --info:#4A6A8A;
        --font-display:'Fraunces','Georgia',serif; --font-body:-apple-system,BlinkMacSystemFont,'Inter',sans-serif; --font-mono:'IBM Plex Mono',monospace;
        font-family:var(--font-body); color:var(--ink); background:var(--parchment); min-height:100%; position:relative;
      }
      .npsuite-root *{box-sizing:border-box;}
      .npsuite-root h1,.npsuite-root h2,.npsuite-root h3{font-family:var(--font-display); margin:0; color:var(--ink);}
      .npsuite-root p{margin:0.35em 0 0; color:var(--ink-soft); line-height:1.5;}
      .npsuite-root button{font-family:inherit; cursor:pointer;}
      .npsuite-root input,.npsuite-root select{font-family:inherit; padding:9px 11px; border:1.5px solid #D8CCB4; border-radius:6px; background:#fff; color:var(--ink); font-size:14px;}
      .npsuite-root input:focus,.npsuite-root select:focus{outline:2px solid var(--seal); outline-offset:1px; border-color:var(--seal);}

      .btn{display:inline-flex; align-items:center; gap:8px; padding:10px 18px; border-radius:7px; border:1.5px solid transparent; font-weight:600; font-size:14px; transition:transform .08s ease, box-shadow .15s ease; text-decoration:none;}
      .btn:active{transform:translateY(1px);}
      .btn-primary{background:var(--ink); color:var(--parchment); border-color:var(--ink);}
      .btn-primary:hover{background:#132038;}
      .btn-ghost{background:transparent; color:var(--ink); border-color:#C9BC9C;}
      .btn-ghost:hover{background:var(--parchment-deep);}
      .paypal-btn{background:#003087; color:#fff; justify-content:center;}
      .paypal-btn:hover{background:#00256b;}
      .venmo-btn{background:#3D95CE; color:#fff; justify-content:center;}
      .venmo-btn:hover{background:#2f7bad;}
      .pay-options{display:flex; flex-direction:column; gap:10px;}
      .btn-lg{padding:13px 24px; font-size:15px;}
      .btn.full{width:100%; justify-content:center;}
      .btn.disabled{opacity:.5; pointer-events:none;}
      .link-btn{background:none; border:none; color:var(--seal-dark); font-weight:600; text-decoration:underline; padding:0;}
      .icon-btn{border:1px solid #D8CCB4; background:#fff; border-radius:5px; padding:6px; display:inline-flex; color:var(--ink-soft);}
      .icon-btn:hover{background:var(--parchment-deep);}
      .icon-btn.danger{color:var(--bad); border-color:#e0c3bc;}

      .brand{display:flex; align-items:center; gap:10px; font-family:var(--font-display); font-size:19px; font-weight:600; color:var(--ink);}
      .brand.center{justify-content:center; margin-bottom:6px;}
      .brand.small{font-size:15px; padding:18px 16px 8px;}

      /* ---- stamp overlay ---- */
      .stamp-overlay{position:fixed; inset:0; z-index:999; display:flex; align-items:center; justify-content:center; pointer-events:none;}
      .stamp-mark{animation:stampPress .62s ease; filter:drop-shadow(0 0 0 var(--seal));}
      .stamp-mark svg{width:120px; height:120px;}
      @keyframes stampPress{0%{transform:scale(2.4) rotate(-8deg); opacity:0;} 30%{transform:scale(1) rotate(0deg); opacity:.95;} 70%{opacity:.85;} 100%{transform:scale(1.05); opacity:0;}}

      .toast{position:fixed; top:18px; right:18px; background:var(--ink); color:var(--parchment); padding:12px 18px; border-radius:8px; font-size:14px; z-index:1000; box-shadow:0 8px 24px rgba(0,0,0,.25);}

      /* ---- landing ---- */
      .landing{max-width:1180px; margin:0 auto; padding:0 24px 60px;}
      .landing-nav{display:flex; justify-content:space-between; align-items:center; padding:22px 0;}
      .nav-actions{display:flex; align-items:center; gap:18px;}
      .hero{display:grid; grid-template-columns:1.1fr .9fr; gap:48px; align-items:center; padding:40px 0 70px;}
      .eyebrow{display:inline-block; font-size:12px; letter-spacing:.08em; text-transform:uppercase; color:var(--seal-dark); font-weight:700; margin-bottom:14px;}
      .hero h1{font-size:42px; line-height:1.12; font-weight:600; max-width:560px;}
      .hero p{font-size:17px; max-width:480px; margin-top:16px;}
      .hero-actions{display:flex; gap:14px; margin-top:28px; flex-wrap:wrap;}
      .hero-trust{display:flex; align-items:center; gap:4px; margin-top:22px; font-size:13px; color:var(--ink-soft);}
      .hero-trust span{margin-left:8px;}
      .hero-visual{display:flex; justify-content:center;}
      .ledger-card{background:#fff; border:1.5px solid var(--parchment-deep); border-radius:14px; padding:26px 28px; width:100%; max-width:340px; box-shadow:0 20px 40px -10px rgba(28,43,69,.18); position:relative;}
      .ledger-row{display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px dashed #E3D9C2; font-family:var(--font-mono); font-size:13.5px;}
      .ledger-row:last-of-type{border-bottom:none;}
      .ledger-row b{font-family:var(--font-mono); color:var(--ink);}
      .ledger-row b.ok{color:var(--ok);}
      .seal-corner{position:absolute; bottom:-18px; right:-14px; opacity:.9;}

      .features{display:grid; grid-template-columns:repeat(4,1fr); gap:18px; padding:20px 0 60px;}
      .feature-card{background:#fff; border:1px solid var(--parchment-deep); border-radius:12px; padding:22px 20px;}
      .feature-icon{width:38px; height:38px; border-radius:9px; background:var(--parchment-deep); color:var(--seal-dark); display:flex; align-items:center; justify-content:center; margin-bottom:14px;}
      .feature-card h3{font-size:16px; margin-bottom:6px;}
      .feature-card p{font-size:13.5px;}

      .pricing{text-align:center; padding:30px 0 60px;}
      .pricing h2{font-size:28px; margin-bottom:26px;}
      .price-card{max-width:380px; margin:0 auto; background:#fff; border:2px solid var(--ink); border-radius:16px; padding:32px 30px; text-align:left;}
      .price-card.in-checkout{border-color:var(--parchment-deep); border-width:1.5px;}
      .price-tag{display:flex; align-items:baseline; gap:8px; justify-content:center; margin-bottom:20px;}
      .price-tag .strike{text-decoration:line-through; color:#B0A488; font-size:18px;}
      .price-tag .now{font-family:var(--font-display); font-size:38px; font-weight:700; color:var(--ink);}
      .price-tag .per{color:var(--ink-soft); font-size:14px;}
      .price-card ul{list-style:none; padding:0; margin:0 0 24px; display:flex; flex-direction:column; gap:10px;}
      .price-card li{display:flex; align-items:center; gap:10px; font-size:14px; color:var(--ink-soft);}
      .price-card li svg{color:var(--ok); flex-shrink:0;}
      .fine-print{font-size:12px; color:#8A7F68; margin-top:10px; text-align:center;}

      .landing-footer{display:flex; justify-content:space-between; padding-top:24px; border-top:1px solid var(--parchment-deep); font-size:13px; color:var(--ink-soft); flex-wrap:wrap; gap:8px;}

      /* ---- auth ---- */
      .auth-screen{min-height:100vh; display:flex; align-items:center; justify-content:center; padding:40px 20px; position:relative;}
      .back{position:absolute; top:24px; left:24px;}
      .auth-card{background:#fff; border:1.5px solid var(--parchment-deep); border-radius:16px; padding:34px 32px; width:100%; max-width:400px; box-shadow:0 24px 48px -12px rgba(28,43,69,.18); text-align:center;}
      .auth-card.wide{max-width:460px;}
      .auth-card h2{font-size:24px; margin-top:8px;}
      .auth-card .sub{margin-bottom:22px; font-size:14px;}
      .auth-card form{text-align:left;}
      .field{display:flex; flex-direction:column; gap:6px; margin-bottom:14px; font-size:13px; font-weight:600; color:var(--ink-soft);}
      .field span{display:flex; align-items:center; gap:6px;}
      .form-err{display:flex; align-items:center; gap:6px; color:var(--bad); font-size:13px; margin-bottom:12px; text-align:left;}
      .switch{margin-top:18px; font-size:13.5px; color:var(--ink-soft);}
      .divider{position:relative; text-align:center; margin:18px 0 14px; font-size:12px; color:#A89C7F;}
      .divider span{background:#fff; padding:0 10px; position:relative;}
      .divider::before{content:""; position:absolute; top:50%; left:0; right:0; height:1px; background:#E3D9C2;}
      .oauth-row{display:flex; gap:10px;}
      .oauth{flex:1; justify-content:center; font-size:13px;}
      .google-g{font-weight:800; color:#4285F4; font-family:Georgia,serif;}
      .oauth-note{font-size:11px; color:#A89C7F; margin-top:8px; text-align:center;}

      /* ---- dashboard ---- */
      .dashboard{display:grid; grid-template-columns:230px 1fr; min-height:100vh;}
      .dash-loading{display:flex; flex-direction:column; align-items:center; justify-content:center; height:100vh; gap:14px; color:var(--ink-soft);}
      .sidebar{background:var(--ink); color:var(--parchment); display:flex; flex-direction:column; padding-bottom:16px;}
      .sidebar .brand span{color:var(--parchment); font-size:15px;}
      .sidebar nav{display:flex; flex-direction:column; gap:2px; padding:10px 12px; flex:1;}
      .nav-tab{display:flex; align-items:center; gap:10px; padding:10px 12px; border-radius:7px; background:none; border:none; color:#C9D2E0; font-size:14px; text-align:left;}
      .nav-tab:hover{background:rgba(255,255,255,.06); color:#fff;}
      .nav-tab.active{background:var(--seal); color:var(--ink); font-weight:700;}
      .sidebar-footer{padding:14px 12px 0; border-top:1px solid rgba(255,255,255,.12); display:flex; flex-direction:column; gap:8px;}
      .plan-badge{font-size:11.5px; padding:6px 10px; border-radius:20px; text-align:center; font-weight:700; letter-spacing:.02em;}
      .plan-badge.trial{background:rgba(184,146,90,.2); color:var(--seal);}
      .plan-badge.active{background:rgba(78,122,91,.25); color:#8FCBA0;}

      .main-panel{padding:32px 40px; overflow-x:auto;}
      .panel-header{display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:22px; gap:16px; flex-wrap:wrap;}
      .panel-header h2{font-size:24px;}
      .panel-header p{font-size:13.5px;}

      .stat-grid{display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:14px; margin-bottom:26px;}
      .stat-card{background:#fff; border:1px solid var(--parchment-deep); border-radius:11px; padding:16px; display:flex; align-items:center; gap:12px;}
      .stat-icon{width:36px; height:36px; border-radius:9px; background:var(--parchment-deep); display:flex; align-items:center; justify-content:center; color:var(--ink); flex-shrink:0;}
      .stat-card.tone-ok .stat-icon{background:#E3EFE6; color:var(--ok);}
      .stat-card.tone-warn .stat-icon{background:#F5E9D8; color:var(--warn);}
      .stat-value{font-family:var(--font-mono); font-size:19px; font-weight:700; color:var(--ink);}
      .stat-label{font-size:12px; color:var(--ink-soft);}

      .card{background:#fff; border:1px solid var(--parchment-deep); border-radius:12px; padding:20px 22px; margin-bottom:18px;}
      .card h3{font-size:15px; margin-bottom:12px; display:flex; align-items:center; gap:8px;}
      .table-card{padding:0; overflow:hidden;}
      .table{width:100%; border-collapse:collapse; font-size:13.5px;}
      .table.mono td{font-family:var(--font-mono); font-size:12.5px;}
      .table th{text-align:left; padding:12px 16px; background:var(--parchment-deep); color:var(--leather); font-size:11.5px; text-transform:uppercase; letter-spacing:.04em; font-weight:700;}
      .table td{padding:11px 16px; border-bottom:1px solid #F1EBDB; color:var(--ink);}
      .table tr:nth-child(even){background:#FBF8F1;}
      .muted{color:#A89C7F; font-size:12px;}
      .muted.small{font-size:13px; margin-bottom:12px;}
      .row-actions{display:flex; gap:6px; justify-content:flex-end;}
      .cal-cell{display:flex; gap:6px;}

      .pill{display:inline-block; padding:3px 10px; border-radius:20px; font-size:11.5px; font-weight:700;}
      .pill.ok{background:#E3EFE6; color:var(--ok);}
      .pill.warn{background:#F5E9D8; color:var(--warn);}
      .pill.bad{background:#F5E0DC; color:var(--bad);}
      .pill.info{background:#E4EAF1; color:var(--info);}
      .pill.gold{background:#F5EAD5; color:var(--seal-dark);}

      .empty-state{display:flex; flex-direction:column; align-items:center; gap:8px; padding:48px 20px; color:#A89C7F; text-align:center;}

      .checklist-grid{display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:14px;}
      .check-row{display:flex; align-items:flex-start; gap:9px; padding:6px 0; font-size:13.5px; color:var(--ink-soft); cursor:pointer;}
      .check-row input{margin-top:3px; accent-color:var(--seal);}
      .check-row .done{text-decoration:line-through; color:#B7AC90;}

      .form-grid{display:grid; grid-template-columns:1fr 1fr; gap:14px 16px;}
      .form-grid .wide{grid-column:1/-1;}
      .form-actions{display:flex; justify-content:flex-end; gap:10px; grid-column:1/-1; margin-top:6px;}
      .inline-form{display:flex; gap:10px; flex-wrap:wrap; margin-bottom:12px;}
      .share-url{flex:1; min-width:220px; font-family:var(--font-mono); font-size:13px;}
      .social-row{display:flex; gap:10px; flex-wrap:wrap;}

      .modal-backdrop{position:fixed; inset:0; background:rgba(28,43,69,.45); display:flex; align-items:center; justify-content:center; z-index:200; padding:20px;}
      .modal{background:#fff; border-radius:14px; max-width:560px; width:100%; max-height:88vh; overflow-y:auto; box-shadow:0 30px 60px -14px rgba(0,0,0,.3);}
      .modal-head{display:flex; justify-content:space-between; align-items:center; padding:18px 22px; border-bottom:1px solid var(--parchment-deep);}
      .modal-body{padding:22px;}

      @media (max-width: 860px){
        .hero{grid-template-columns:1fr;}
        .features{grid-template-columns:repeat(2,1fr);}
        .dashboard{grid-template-columns:1fr; grid-template-rows:auto 1fr;}
        .sidebar{flex-direction:row; overflow-x:auto; align-items:center; padding:10px;}
        .sidebar nav{flex-direction:row;}
        .sidebar-footer{flex-direction:row;}
        .form-grid{grid-template-columns:1fr;}
        .main-panel{padding:20px;}
      }
      @media (prefers-reduced-motion: reduce){
        .stamp-mark{animation:none; opacity:.9;}
      }
    `}</style>
  );
}
