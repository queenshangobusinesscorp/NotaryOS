# Notary Pro Suite — backend

This is the real, deployable backend: authentication, data storage, and
Stripe subscription billing that auto-activates a notary's account the
moment they pay you.

The code is done. The steps below are things **only you can do**, because
they require your own accounts and identity.

## 1. Create your accounts

- **Stripe** (stripe.com) — your business account, the one that receives
  the $19/mo subscription money.
- **A Postgres database** — easiest options: [Supabase](https://supabase.com)
  (free tier) or a Postgres add-on on [Render](https://render.com) or
  [Railway](https://railway.app).
- **A place to host this server** — Render, Railway, or Fly.io all work;
  Render's free/starter web service is the simplest to start with.

## 2. Set up Stripe

1. Dashboard → **Product catalog** → **Add product** → name it
   "Notary Pro Suite Subscription" → set a **recurring price** of $19.00/month.
2. Copy that price's ID (starts with `price_`) → goes in `STRIPE_PRICE_ID`.
3. Dashboard → **Developers → API keys** → copy the **Secret key**
   (starts with `sk_`) → goes in `STRIPE_SECRET_KEY`.
   Use the **test** key first, switch to **live** only once everything works.

## 3. Create the database tables

Run `schema.sql` once against your new database. With `psql` installed:

```bash
psql "$DATABASE_URL" -f schema.sql
```

(Supabase and Render both also let you paste this into a web-based SQL editor.)

## 4. Configure environment variables

Copy `.env.example` to `.env` and fill in your real values:

```bash
cp .env.example .env
```

Generate a random `JWT_SECRET`:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

`STRIPE_WEBHOOK_SECRET` comes from step 6 below — leave it blank for now.

## 5. Install and run locally first

```bash
npm install
npm start
```

You should see `Notary Pro Suite backend listening on port 3000`.

## 6. Deploy, then connect the webhook

1. Push this folder to a GitHub repo, then connect it in Render/Railway as
   a new Web Service. Set the same environment variables there.
2. Once deployed, you'll have a URL like `https://notary-api.onrender.com`.
3. In Stripe Dashboard → **Developers → Webhooks → Add endpoint**:
   - Endpoint URL: `https://notary-api.onrender.com/api/webhooks/stripe`
   - Events to send: `checkout.session.completed`,
     `customer.subscription.updated`, `customer.subscription.deleted`
4. Stripe shows you a **Signing secret** (`whsec_...`) — put that in your
   deployed environment variables as `STRIPE_WEBHOOK_SECRET`, then redeploy.

## 7. Test it end-to-end before going live

With the [Stripe CLI](https://stripe.com/docs/stripe-cli) installed:

```bash
stripe listen --forward-to localhost:3000/api/webhooks/stripe
stripe trigger checkout.session.completed
```

Confirm in your database that a user's `plan` column flips to `active`.
Only switch `STRIPE_SECRET_KEY` and the webhook to **live mode** once this
test passes.

## 8. Connect the frontend

Good news: `notary_pro_suite.jsx` is already wired for this. Open the file and
find the `CONFIG` block near the top:

```js
const CONFIG = {
  API_BASE: "", // e.g. "https://notary-api.onrender.com" — no trailing slash
};
```

Paste in your deployed backend's URL. That's it — the whole app (auth,
appointments, clients, journal, bookkeeping, checklist, settings, and the
"Subscribe" button) automatically switches from the built-in demo storage
to real `fetch` calls against this API, using a bearer token from login.

Leaving `API_BASE` empty keeps the app running exactly as it does today
inside Claude's artifact preview — that's intentional, so you can keep
demoing it there even after the backend exists elsewhere.

## Security notes

- Passwords are hashed with bcrypt — never stored in plain text.
- The webhook verifies Stripe's signature before trusting any event —
  never skip that check.
- Keep `.env` out of any public repo (add it to `.gitignore`).
- Consider rate-limiting `/api/auth/login` in production to slow down
  password-guessing attempts (e.g. the `express-rate-limit` package).
